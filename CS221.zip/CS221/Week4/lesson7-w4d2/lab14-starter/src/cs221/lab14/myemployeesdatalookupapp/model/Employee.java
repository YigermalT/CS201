package cs221.lab14.myemployeesdatalookupapp.model;

/**
 * This is the Employee class from which Employee objects will be
 * created, and used as values for the data lookup table.
 * @author obi
 *
 */
public class Employee {
	
	private String name;
	private double salary;
	
	public Employee(String name) {
		this.name = name;
	}
	
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}
	
	public String getName() { return this.name; }
	public void setName(String name) { this.name = name; }
	
	public double getSalary() { return this.salary; }
	public void setSalary(double salary) { this.salary = salary; }
	
	public String toString() {
		return this.name;
	}
	
	// TODO 1: Add any methods required/necessary for implementing the app, as specified.
}

