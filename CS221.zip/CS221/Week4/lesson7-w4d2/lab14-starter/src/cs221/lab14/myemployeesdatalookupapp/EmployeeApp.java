package cs221.lab14.myemployeesdatalookupapp;

public class EmployeeApp {

	public static void main(String[] args) {
		Employee emp0 = new Employee("John", 15000.0);
		Employee emp1 = new Employee("Anna", 25000.0);
		Employee emp2 = new Employee("Ben", 75000.0);
		Employee[] emps = new Employee[3];
		emps[0] = emp0;
		emps[1] = emp1;
		emps[2] = emp2;
		MyEmployeeLookupTable myEmpLookupTable = new MyEmployeeLookupTable();
		myEmpLookupTable.createEmployeeLookupTable(emps);
		
		// FindEmployeeSalaries
		Employee targetAnna = new Employee("Anna", 25000.0);
		double annaSalary = myEmpLookupTable.findEmployeeSalary(targetAnna);
		System.out.println("Salary for Anna is: " + annaSalary);
		
		Employee targetJohn = new Employee("John", 15000.0);
		double johnSalary = myEmpLookupTable.findEmployeeSalary(targetJohn);
		System.out.println("Salary for John is: " + johnSalary);
		
		Employee targetBen = new Employee("Ben", 75000.0);
		double benSalary = myEmpLookupTable.findEmployeeSalary(targetBen);
		System.out.println("Salary for Ben is: " + ((benSalary != -1.0) ? benSalary : "RECORD NOT FOUND"));
		
		Employee targetMary = new Employee("Mary", 25000.0);
		double marySalary = myEmpLookupTable.findEmployeeSalary(targetMary);
		System.out.println("Salary for Mary is: " + ((marySalary != -1.0) ? marySalary : "RECORD NOT FOUND"));
		System.out.println();
		
		System.out.println("Is Anna present: " + ((myEmpLookupTable.isEmployeePresent(targetAnna)) ? "Yes" : "No"));
		System.out.println("Is Mary present: " + ((myEmpLookupTable.isEmployeePresent(targetMary)) ? "Yes" : "No"));
		System.out.println("Is John present: " + ((myEmpLookupTable.isEmployeePresent(targetJohn)) ? "Yes" : "No"));
		//TODO 6: Add line here to test if Ben is present in the lookup table
	}
}
