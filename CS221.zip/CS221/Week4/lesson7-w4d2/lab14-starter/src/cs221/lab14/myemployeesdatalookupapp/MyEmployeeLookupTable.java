package cs221.lab14.myemployeesdatalookupapp;

public class MyEmployeeDataTable {
	
	// TODO 2: Declare and initialize a HashMap object here, to be used
	// to store the Employee data, received from an input array. Your
	// HashMap will serve as a lookup table such that, when an 
	// Employee object is passed as the key, his/her salary will be
	// retrieved as the value.
	// NOTE: Data type for the key should be, Employee,
	// and the data type for the value should be, Double
	

	public void createEmployeeLookupTable(Employee[] emps) {
		// TODO 3: Populated the lookup table here, using data
		// received from the input array named, emps.
	}
	
	public boolean isEmployeePresent(Employee emp) {
		// TODO 4: Implement this method to return true
		// if the given Employee object, emp is present
		// in the lookup table, and false, otherwise.
	}
	
	// TODO 5: Returns the salary for the given Employee, emp
	// if present in the lookup table, otherwise, returns -1.0
	public double findEmployeeSalary(Employee emp) {
		
	}
}
