Package C:\Users\abush\Desktop\MUM\CS221\cs221\edu\mum\cs221\lesson1\oopreview\model

Class Classroom {
private int classrommId;
private String roomLabel;
private String buildingName;

int getClassroomId() {return classrommId;}
String getRoomLabeloomLabel () { return roomLabel;}
String getBuildingName() {return buildingName;}

void setClassrommId (int classrommId){
	this.classrommId = classrommId; 
}

void setRoomLabel(String roomLabel){
	this.roomLabel = roomLabel;
}


void setBuildingName( String buildingName ){
	this.buildingName = buildingName;
}
}