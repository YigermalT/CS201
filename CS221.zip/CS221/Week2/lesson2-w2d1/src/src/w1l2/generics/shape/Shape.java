package w1l2.generics.shape;

public interface Shape {
	double computeArea();
}
