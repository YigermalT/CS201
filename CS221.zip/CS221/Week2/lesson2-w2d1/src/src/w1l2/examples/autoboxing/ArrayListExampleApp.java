package w1l2.examples.autoboxing;

import java.util.ArrayList;

class ArrayListExampleApp {

	public static void main(String[] args) {
		
		int[] nums = {5, 7, 2, 15};
		
		ArrayList<Integer> someInts = new ArrayList<Integer>();
//		ArrayList<Integer> someInts = new ArrayList<>();
//		List<Integer> someInts = new ArrayList<Integer>();
//		List<Integer> someInts = new ArrayList<>();
		
		for(int i = 0; i < nums.length; i++) {
			someInts.add(nums[i]); // Note: Auto-boxing is done here i.e. someInts.add(new Integer(nums[1]));
		}
		
		// Display the sum
		int sum = 0;
		for(int i = 0; i < someInts.size(); i++) {
			sum += someInts.get(i); // Note: Auto-unboxing is done here i.e. someInts.get(i).intValue();
		}

		System.out.println("Sum is " + sum);
		
		// Use of toArray()
		Object[] a_out = someInts.toArray();
		for(Object i : a_out) {
			System.out.printf("%d ", i);
		}
		
		//System.out.println(someInts.get(-1));
		
	}
}
