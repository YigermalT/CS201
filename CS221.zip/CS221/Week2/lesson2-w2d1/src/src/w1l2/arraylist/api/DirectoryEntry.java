package w1l2.arraylist.api;

import java.util.ArrayList;

/**
 * The DirectoryEntry objects will contain name-and-number pairs. The name is
 * immutable; that is, it cannot be changed. (Note: There is no setName(...) method).
 */
public class DirectoryEntry {

	// Data Fields
	/** The name of the individual represented in the entry. */
	private String name;
	/** The phone number for this individual. */
	private String number;

	// Constructor
	/**
	 * Creates a new DirectoryEntry with the specified name and number
	 * 
	 * @param name
	 *            The name of this individual
	 * @number The phone number for this indvidual
	 */
	public DirectoryEntry(String name, String number) {
		this.name = name;
		this.number = number;
	}

	// Methods
	/**
	 * Retrieves the name.
	 * 
	 * @return The name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Retrieves the number.
	 * 
	 * @return The number.
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * Sets the number to the specified value
	 * 
	 * @param number The new value for the number
	 */
	public void setNumber(String number) {
		this.number = number;
	}
	
//	@Override
//	public boolean equals(Object object) {
//		if(object == null) return false;
//		if(this == object) return true;
//		if(!(object instanceof DirectoryEntry)) return false;
//		DirectoryEntry de = (DirectoryEntry)object;
//		if(this.name == null) {
//			if(de.name != null) { 
//				return false;
//			} 
//		} 
//		if (this.number == null) {
//			if(de.number != null) {
//				return false;
//			}
//		}
//		return this.name.equals(de.name) && this.number.equals(de.number);
//	}
		
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (!(obj instanceof DirectoryEntry)) return false;
		DirectoryEntry other = (DirectoryEntry) obj;
		if (name == null) {
			if (other.name != null) return false;
		} else if (!name.equals(other.name)) return false;
		if (number == null) {
			if (other.number != null) return false;
		} else if (!number.equals(other.number)) return false;
		return true;
	}

	@Override
	public String toString() {
		return "DirectoryEntry [name=" + name + ", number=" + number + "]";
	}

	public static void main(String args[]){
		ArrayList<DirectoryEntry> theDirectory = new ArrayList<DirectoryEntry>();
		// adding elements
		theDirectory.add(new DirectoryEntry("Renuka","641-456-9229"));
		theDirectory.add(new DirectoryEntry("Tommy","641-458-2229"));
		theDirectory.add(new DirectoryEntry("Henry","641-451-0001"));
		System.out.println("Directory List:");
		System.out.println(theDirectory);
		
		// Getting the size		
		System.out.println("Size of theDirectory : " + theDirectory.size());
		
		// Get the element by passing index		
		System.out.println("Element at the index 1 : " + theDirectory.get(1));
	
		// Modify the value - Set the new value		
		theDirectory.set(0, new DirectoryEntry("Renuka","641-456-2556"));
		System.out.println("Element at the index 0 : " + theDirectory.get(0));
		
		// Remove the index 1
		theDirectory.remove(1);
		System.out.println("After removing Tommy, Directory List is now:");
		System.out.println(theDirectory);
		System.out.println("Size of theDirectory : " + theDirectory.size());
		
		// Find/Search for a given DirectoryEntry using indexOf
		DirectoryEntry deHenry = new DirectoryEntry("Henry","641-451-0001");
		int index = theDirectory.indexOf(deHenry);
		if(index != -1) {
			System.out.println("FOUND: " + theDirectory.get(index));
		} else {
			System.out.println(deHenry + " is NOT FOUND!");
		}
	}

}
