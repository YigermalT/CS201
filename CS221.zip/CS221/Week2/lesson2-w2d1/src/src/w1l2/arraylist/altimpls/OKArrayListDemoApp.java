package w1l2.arraylist.altimpls;

class OKArrayListDemoApp {

	public static void main(String[] args) {
		
    	OKArrayList<String> str = new OKArrayList<String>();
    	System.out.println("Initial capacity : " + str.getCapacity());
    	System.out.println("Size of the list : " + str.size());
    	str.add("Java");
    	str.add("Data Structures");
    	System.out.println(str);
    	System.out.println("Size of the list : " + str.size());
    	str.add(1,"C#");
    	System.out.println(str);
    	System.out.println("Size of the list : " + str.size());
    	str.add("Design Pattern");
    	str.remove(1);    	
    	System.out.println(str);
    	System.out.println("Size of the list : " + str.size());
    	System.out.println("Index of C# : "+ str.indexOf("C#"));
    	System.out.println("Index of Java : "+ str.indexOf("Java"));
    	System.out.println("Element at the index 2 : " + str.get(2));
    	System.out.println("Set the value at the index 1 : " + str.set(1,"Software Engineering"));
    	
    	System.out.println(str); // ***
    	
    	// Test resize() by creating zero capacity OKArrayList
//    	OKArrayList<String> str0 = new OKArrayList<String>(0);
//    	System.out.println("Initial capacity : " + str0.getCapacity());
//    	System.out.println("Size of the list : " + str0.size());
//    	str0.add("Java");
//    	System.out.println(str0);
//    	System.out.println("capacity : " + str0.getCapacity());
//    	System.out.println("Size of the list : " + str0.size());

	}

}
