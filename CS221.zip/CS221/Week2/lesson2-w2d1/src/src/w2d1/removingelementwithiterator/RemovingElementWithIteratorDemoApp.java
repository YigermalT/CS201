package w2d1.removingelementwithiterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class RemovingElementWithIteratorDemoApp {

	public static void main(String[] args) {
		
		//List<Integer> list = Arrays.asList(1,2,3,4,5); CAUTION: Does NOT work for immutable list
		List<Integer> list = new ArrayList<>(); 
		list.add(1); list.add(2); list.add(3); list.add(4); list.add(5);
		
		System.out.printf("%s", list);
		System.out.println();
		
		Iterator<Integer> it = list.iterator();
		it.next(); // Notice this call to next() before call to it.remove()
		it.remove();
		System.out.printf("%s", list);
	}

}
