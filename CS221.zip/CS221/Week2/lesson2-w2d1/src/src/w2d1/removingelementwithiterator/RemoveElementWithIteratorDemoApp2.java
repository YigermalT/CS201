package w2d1.removingelementwithiterator;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class RemoveElementWithIteratorDemoApp2 {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();
		list.add(1); list.add(2); list.add(3); list.add(4); list.add(5);
		System.out.printf("%s", list);
		System.out.println();
		removeDivisibleBy(list, 2);
		System.out.printf("%s", list);
		System.out.println();
	}
	
	public static void removeDivisibleBy(List<Integer> aList, int div) {
		Iterator<Integer> iter = aList.iterator();
		while (iter.hasNext()) {
			int nextInt = iter.next();
			if (nextInt % div == 0) {
				iter.remove();
			}
		}
	}
}
