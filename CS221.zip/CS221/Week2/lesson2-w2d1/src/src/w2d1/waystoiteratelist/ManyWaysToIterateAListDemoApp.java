package w2d1.waystoiteratelist;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

class ManyWaysToIterateAListDemoApp {

	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		
		// Option 1: Using the classic for...loop
		System.out.print("Option 1, using for...loop: ");
		for (int i = 0; i < list.size(); i++) {
			System.out.printf("%d", list.get(i));
			if (i < list.size() - 1)
				System.out.printf(", ");
		}
		
		System.out.println();
		///////////////////////////////////////////////////////////
		
		// Option 2: Using a while...loop
		System.out.print("Option 2, using while...loop: ");
		int i = 0;
		while (i < list.size()) {
			System.out.printf("%d", list.get(i));
			if (i < list.size() - 1)
				System.out.printf(", ");
			i++;
		}
		
		System.out.println();
		///////////////////////////////////////////////////////////
		
		// Option 3: Using the enhanced for statement, aka foreach...statement block
		System.out.print("Option 3, using foreach statement: ");
		int counter = 1;
		for (Integer num : list) {
			System.out.printf("%d", num);
			if (counter < list.size())
				System.out.printf(", ");
			counter++;
		}
		
		System.out.println();
		///////////////////////////////////////////////////////////
		
		// Option 4: Using an Iterator object with while...loop
		System.out.print("Option 4, using Iterator with while...loop: ");
		Iterator<Integer> it1 = list.iterator();
		while (it1.hasNext()) {
			System.out.printf("%d", it1.next());
			if (it1.hasNext())
				System.out.printf(", ");
		}
		
		System.out.println();
		///////////////////////////////////////////////////////////
		
		// Option 5: Using an Iterator object with for...loop
		System.out.print("Option 5, using Iterator with for...loop: ");
		for (Iterator<Integer> it2 = list.iterator(); it2.hasNext(); ) {
			System.out.printf("%d", it2.next());
			if (it2.hasNext())
				System.out.printf(", ");
		}
		
		System.out.println();
		///////////////////////////////////////////////////////////
		
		// Option 6: Using Java 8 Functional programming style with forEach and lambda expression
		System.out.print("Option 6, using forEach and lambda expression: ");
		list.forEach(n -> System.out.printf("%d, ", n));
		
		System.out.println();
		///////////////////////////////////////////////////////////		
		
		// Option 7: Using Java 8 Stream APIs
		System.out.print("Option 7, using Stream APIs: ");
		System.out.println(list.stream().map(n -> Integer.toString(n)).collect(Collectors.joining(", ")));
	}

}
