package w2d1.usingcomparator;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import w2d1.usingcomparator.model.Employee;

class UsingEmpComparatorDemoApp {

	public static void main(String[] args) {
		List<Employee> emps = Arrays.asList(
				new Employee("Devin", 20000.0),
				new Employee("Ana", 41000.0),
				new Employee("Carlos", 50000.0),
				new Employee("Ed", 10000.0),
				new Employee("Ana", 40000.0),
				new Employee("Bob", 10000.0)
			);
			
			System.out.println(emps);
			
			// Sort list of employees by their salary
			Comparator<Employee> c = new EmployeeSalaryComparator();
			Collections.sort(emps, c);
			System.out.println(emps);

	}

}
