package w2d1.usingcomparator.model;

public class Employee {
	private String name;
	private double salary;
	
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}
	
	public double getSalary() { return salary; }
	public String getName() { return name; }
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (this == obj) return true;
		if (!(obj instanceof Employee)) return false;
		Employee emp = (Employee) obj;
		return (this.name.equals(emp.name) && this.salary == emp.salary);
	}
	
	@Override
	public String toString() {
		return String.format("{name: %s, salary: %,.2f}", name, salary);
	}
}
