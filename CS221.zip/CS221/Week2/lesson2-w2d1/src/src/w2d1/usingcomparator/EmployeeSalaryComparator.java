package w2d1.usingcomparator;

import java.util.Comparator;

import w2d1.usingcomparator.model.Employee;

class EmployeeSalaryComparator implements Comparator<Employee> {

	// NOT CONSISTENT WITH Employee.equals, because does not consider Employee names
	@Override
	public int compare(Employee e1, Employee e2) {	
		if (e1.getSalary() < e2.getSalary()) {
			return -1;
		} else if (e1.getSalary() > e2.getSalary()) {
			return 1;
		}
		return 0;
	}
	
	// Consistent with equals, because if salaries are equals, it then considers names
//	@Override
//	public int compare(Employee e1, Employee e2) {	
//		if (e1.getSalary() < e2.getSalary()) {
//			return -1;
//		} else if (e1.getSalary() > e2.getSalary()) {
//			return 1;
//		}
//		return e1.getName().compareTo(e2.getName());
//	}
}
