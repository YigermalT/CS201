package w2d1.usingiterator;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class UsingIteratorDemoApp {

	public static void main(String[] args) {
		
		List<Integer> ints = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		// Using Iterator to iterate through the list and print-out its values
		Iterator<Integer> it = ints.iterator();
		while (it.hasNext()) {
			System.out.printf("%d", it.next());
			if (it.hasNext())
				System.out.printf(", ");
		}
		
	}

}
