package w2d1.usingcomparable.model;

public class Employee implements Comparable<Employee> {
	private String name;
	private double salary;
	
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (this == obj) return true;
		if (!(obj instanceof Employee)) return false;
		Employee emp = (Employee) obj;
		return (this.name.equals(emp.name) && this.salary == emp.salary);
	}
	
	@Override
	public String toString() {
		return String.format("{name: %s, salary: %,.2f}", name, salary);
	}

	// NOT Consistent with equals()
	@Override
	public int compareTo(Employee e) {
		return (this.name.compareTo(e.name));
	}
	
	// Consistent with equals()
//	@Override
//	public int compareTo(Employee e) {
//		if (this.name.compareTo(e.name) != 0) {
//			return (this.name.compareTo(e.name));
//		}
//		if (this.salary < e.salary) {
//			return -1;
//		} else if (this.salary > e.salary) {
//			return 1;
//		} 
//		return 0;
//	}
}
