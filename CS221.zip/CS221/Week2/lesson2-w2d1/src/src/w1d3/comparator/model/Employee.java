package w1d3.comparator.model;

public class Employee {
	private String name;
	private double salary;
	
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}
	
	public String toString() {
		return String.format("{name: %s, salary: %,.2f}", name, salary);
	}
}
