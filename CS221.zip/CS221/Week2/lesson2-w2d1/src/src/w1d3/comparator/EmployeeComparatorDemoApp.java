package w1d3.comparator;

class EmployeeComparatorDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
