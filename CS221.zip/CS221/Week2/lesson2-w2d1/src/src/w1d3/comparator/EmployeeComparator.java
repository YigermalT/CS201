package w1d3.comparator;

import java.util.Comparator;

import w1d3.comparator.model.Employee;

class EmployeeComparator implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		
		return 0;
	}
	
}
