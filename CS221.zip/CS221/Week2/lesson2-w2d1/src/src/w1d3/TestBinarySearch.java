package w1d3;

import java.util.Arrays;

public class TestBinarySearch {
	public static void main(String[] args) {
		int[] a = { 22, 33, 44, 55, 66, 77, 88, 99 };

		System.out.println("search(a, 44): " + search(a, 44));
		System.out.println("search(a, 50): " + search(a, 50));
		System.out.println("search(a, 77): " + search(a, 77));
		
		long startTime = System.nanoTime();
		System.out.println("search(a, 99): " + search(a, 99));
		long finishTime = System.nanoTime();
		
		long t = finishTime - startTime;		
		System.out.println("Binary Search Time-taken : " + t);
		
		System.out.println();
		System.out.println("search(a, 77): " + Arrays.binarySearch(a, 77));
	}

	public static int search(int[] a, int x) {
		int low = 0;
		int hig = a.length - 1;

		while (low <= hig) {
			int mid = (low + hig) / 2;
			if (a[mid] == x) {
				return mid;
			} else if (a[mid] < x) {
				low = mid + 1;
			} else {
				hig = mid - 1;
			}
		}
		return -1;
	}
}