package w1d3.bigo;

class NTimesMGrowthRate {

	public static void main(String[] args) {
		int[] x = { 22, 34, 11, 58, 16, 77, 65, 19 };
		int[] y = { 22, 34, 11, 58, 16, 77, 65, 19 };
		System.out.println(areDifferent(x, y)); // Question: Is the result correct? Yes or No? 
		
		int[] a = { 20, 34, 11, 58, 16, 77, 64, 19 };
		int[] b = { 22, 34, 11, 58, 16, 77, 65, 19 };
		System.out.println(areDifferent(a, b)); // Question: Is the result correct? Yes or No? 
	}

	// EXERCISE
	private static boolean areDifferent(int[] x, int[] y) {
		for (int i = 0; i < x.length; i++) {
			if (search(y, x[i]) != -1)
				return false;
		}
		return true;
	}
	
	// EXERCISE
	private static int search(int[] a, int x) {
		for (int i = 0; i < a.length; i++) { 
			if (a[i] == x) {
				return i;
			}
		}
		return -1;
	}
	
	// BUG FIXED
//	private static boolean areDifferent(int[] x, int[] y) {
//		for (int i = 0; i < x.length; i++) {
//			if (search(y, x[i]) == -1)
//				return true;
//		}
//		return false;
//	}	

}
