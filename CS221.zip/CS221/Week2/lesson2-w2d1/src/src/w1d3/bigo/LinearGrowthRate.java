package w1d3.bigo;

class LinearGrowthRate {

	public static void main(String[] args) {		
		int[] a = { 22, 34, 11, 58, 16, 77, 65, 19 };
		System.out.println("search(a, 34): " + search(a, 34));
		System.out.println("search(a, 50): " + search(a, 50));
	}
	
	public static int search(int[] a, int x) {
		for (int i = 0; i < a.length; i++) { // step 1

			if (a[i] == x) {
				return i;
			}
		}
		return -1;
	}

}
