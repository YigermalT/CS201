package w1d3.bigo;

class QuadraticGrowthRate {

	public static void main(String[] args) {
		int[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		System.out.println(areUnique(a)); // TestCase A - What is output?
		
		int[] b = { 1, 2, 3, 4, 5, 6, 7, 7, 9, 10 };
		System.out.println(areUnique(b)); // TestCase B	- What is output?	
	}
	
	// EXERCISE 1
	public static boolean areUnique(int[] x) {
		for(int i=0; i < x.length; i++) {
			for(int j=0; j < x.length; j++) {
				if (i != j && x[i] == x[j])
					return false;
			}
		}
		return true;
	}
	
	// EXERCISE 2: Add some code above to count the total number of times the inner for..loop executes?
	
	// Algorithm Analysis concept: Best-case, Worst-case, Average-case

}
