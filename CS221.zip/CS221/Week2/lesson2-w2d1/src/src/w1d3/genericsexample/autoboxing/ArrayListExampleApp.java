package w1d3.genericsexample.autoboxing;

import java.util.ArrayList;
import java.util.List;

class ArrayListExampleApp {

	public static void main(String[] args) {
		
		int[] nums = {5, 7, 2, 15};
		
		// Fours ways of creating a generic type ArrayList of Integer
		ArrayList<Integer> someInts1 = new ArrayList<Integer>(); // full; lacks use of polymorphism
		ArrayList<Integer> someInts2 = new ArrayList<>(); // using the <diamond> operator (from Java 7); type inference
		List<Integer> someInts3 = new ArrayList<Integer>(); // // full; supports use of polymorphism
		List<Integer> someInts4 = new ArrayList<>(); // using the <diamond> operator and supporting polymorphism
		
		someInts1.add(1);
		someInts2.add(2);
		someInts3.add(3);
		someInts4.add(4);		
//		someInts4.add("Hello"); // Gives a compiler error
		
		for(int i = 0; i < nums.length; i++) {
			someInts1.add(nums[i]); // Note: Auto-boxing is done here i.e. someInts.add(new Integer(nums[1]));
		}
		
		// Display the sum
		int sum = 0;
		for(int i = 0; i < someInts1.size(); i++) {
			sum += someInts1.get(i); // Note: Auto-unboxing is done here i.e. someInts.get(i).intValue();
		}

		System.out.println("Sum is " + sum);
		
		// Use of toArray()
		Object[] a_out = someInts1.toArray();
		for(Object i : a_out) {
			System.out.printf("%d ", i);
		}
		
		//System.out.println(someInts.get(-1));
		
	}
}
