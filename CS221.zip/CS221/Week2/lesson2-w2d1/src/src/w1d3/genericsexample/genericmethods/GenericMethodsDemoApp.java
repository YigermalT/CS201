package w1d3.genericsexample.genericmethods;

import w1d3.genericsexample.genericmethods.model.Employee;

class GenericMethodsDemoApp {

	public static void main(String[] args) {
		int[] ints = {1, 2, 3, 4, 5}; // Gives compile error because value passed to generic type parameter
									  // cannot be of primitive type, but must be of Object (reference) type.
		Integer[] Ints = {1, 2, 3, 4, 5};
		String[] s = {"AK", "AL", "AR", "AZ", "CA"};
		Employee[] emps = {new Employee("Ana", 50000.0599), new Employee("Bob", 20000.0), new Employee("Chris", 55000.0)};

		//printInts(ints);
//		printInts(s); // Gives compile error
		//printStrings(s);
//		printEmps(emps);
		
		print(Ints);
//		print(ints); // Gives compile error because value passed to generic type parameter
					// cannot be of primitive type, but must be of Object (reference) type.
		print(s);
		
		print(emps);
	}
	
	private static void printInts(int[] ints) {
		int len = ints.length;
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i < len; i++) {
			String dataFormat = (len - i > 1) ? "%s, " : "%s";
			sb.append(String.format(dataFormat, ints[i]));
		}
		sb.append("]");
		System.out.println(sb);
		System.out.println();
	}
	
	private static void printStrings(String[] s) {
		int len = s.length;
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i < len; i++) {
			String dataFormat = (len - i > 1) ? "%s, " : "%s";
			sb.append(String.format(dataFormat, s[i]));
		}
		sb.append("]");
		System.out.println(sb);
		System.out.println();
	}
	
	private static <T> void print(T[] arrT) {
		int len = arrT.length;
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i < len; i++) {
			String dataFormat = (len - i > 1) ? "%s, " : "%s";
			sb.append(String.format(dataFormat, arrT[i]));
		}
		sb.append("]");
		System.out.println(sb);
		System.out.println();
	}

}
