package w1d3.genericsexample.wildcards;

import java.util.Arrays;
import java.util.List;

import w1d3.genericsexample.genericmethods.model.Employee;

public class WildcardsExampleDemoApp {

	public static void main(String[] args) {
		////////////////////////////////////////////
		// UnBounded Wildcard
		////////////////////////////////////////////
		List<Integer> nums = Arrays.asList(1,2,3,4,5);
		List<?> list = nums;
		print(list);
		
		List<String> names = Arrays.asList("Ana", "Bob", "Carlos");		
		list = names;
		print(list);
		
		List<Employee> emps = Arrays.asList(
				new Employee("Ana", 50000.0599), 
				new Employee("Bob", 20000.0), 
				new Employee("Chris", 55000.0)
		);
		list = emps;
		print(emps);
		
		////////////////////////////////////////////
		// Bounded Wildcard - ? extends and ? super
		////////////////////////////////////////////
		List<? extends Number> numss = Arrays.asList(1, 2.50, 7.3f, Byte.MAX_VALUE);
		for (Number num : numss) {
			System.out.printf("%s, ", num);
		}
		System.out.println();
		
		List<? super Integer> objs = Arrays.asList(1, "string", new Employee("Ana", 50000.0599));
		for (Object obj : objs) {
			System.out.printf("%s, ", obj);
		}
		System.out.println();
		
	}
	
	private static <T> void print(List<T> list) {
		int len = list.size();
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for(int i = 0; i < len; i++) {
			String dataFormat = (len - i > 1) ? "%s, " : "%s";
			sb.append(String.format(dataFormat, list.get(i)));
		}
		sb.append("]");
		System.out.println(sb);
		System.out.println();
	}
	
//	private static <T> void print(Collection<T> coll) { // Wildcard capture
//		print(coll);
//	}

}
