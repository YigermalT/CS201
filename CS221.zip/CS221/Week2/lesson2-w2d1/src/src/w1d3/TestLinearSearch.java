package w1d3;

public class TestLinearSearch {
	public static void main(String[] args) {
		int[] a = { 22, 34, 11, 58, 16, 77, 65, 19 };
		System.out.println("search(a, 34): " + search(a, 34));
		System.out.println("search(a, 50): " + search(a, 50));
		
		long startTime = System.nanoTime();
		System.out.println("search(a, 19): " + search(a, 19));
		long finishTime = System.nanoTime();
		long t = finishTime - startTime;		
		System.out.println("Linear Search Time-taken : " + t);
		
		System.out.println("search(a, 100): " + search(a, 100));
	}

	public static int search(int[] a, int x) {
		for (int i = 0; i < a.length; i++) { // step 1

			if (a[i] == x) {
				return i;
			}
		}
		return -1;
	}
}