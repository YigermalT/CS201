package edu.mum.cs.cs221.lesson1.oopreview2;

public class Square {

	int side;
	float d;
	int area(){
		int x;
		return side * side;
	}
	Square(int side){
		this.side = side;
	}
	
}
