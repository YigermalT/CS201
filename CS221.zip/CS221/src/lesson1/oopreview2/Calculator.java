package edu.mum.cs.cs221.lesson1.oopreview2;

public interface Calculator {
	public abstract int add(int x, int y);
	int sub(int x,int y);
	int mul(int x,int y);
	void display();
		
	
	
	}
