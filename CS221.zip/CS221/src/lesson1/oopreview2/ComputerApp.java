package edu.mum.cs.cs221.lesson1.oopreview2;

class ComputerApp {

    public static void main(String[] args) {
        Computer comp[] = new Computer[3];
        comp[0] = new Computer("Acme", "AMD", 3, 160, 2.4);
        comp[1] = new Notebook("Dell", "Intel", 4, 350, 2.2, 15.5, 7.5);
        comp[2] = comp[1];

    	System.out.println("Computer0");
        System.out.println(comp[0]);
        System.out.println();
        
    	System.out.println("Notebook1");
        System.out.println(comp[1]);
        System.out.println();

    	System.out.println("Computer2");
        System.out.println(comp[2]);
        System.out.println();
        
//        Computer theComputer = new Notebook2("Bravo", "Intel", 4, 240, 2.4, 15.0, 7.5);
//        System.out.println("Notebook2");
//        System.out.println(theComputer.toString());
//        System.out.println();
        
        System.out.println("Equality : " + comp[1].equals(comp[2]));
        System.out.println("Equality : " + comp[0].equals(comp[2]));
        
    } 

}
