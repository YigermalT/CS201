package edu.mum.cs.cs221.lesson1.javabasics;

class CastingDemoApp {

	public static void main(String[] args) {
		
		// No casting needed
		Student student1 = new Student("Ben");
		String student1Name = student1.getName();
		System.out.println("Student1's name is: " + student1Name);
		
		// Casting from a super-class (general type) to sub-class (specific type)
		Object student2 = new Student("Antwan");
		//String student2Name = student2.getName(); // produces compile-error - getName() is undefined for type Object
		
		System.out.println(student2); // Polymorphism -- See the executed code in java.io.PrintStream.println(Object) method
		
		// Casting is needed
		String student2Name = ((Student)student2).getName(); // casting done here
		System.out.println("Student2's name is: " + student2Name);
	}

}
