package edu.mum.cs.cs221.lesson1.javabasics;

import java.time.LocalDate;
import java.util.Arrays;

class ArraysDemoApp {

	public static void main(String[] args) {
		// how to create an array - declaration, construction and initialization of array
		// array of primitive data-types
		int[] ints = new int[3];
		ints[0] = 1;
		ints[1] = 2;
		ints[2] = 3;
		for(int i : ints) {
			System.out.printf("%d ", i);
		}
		System.out.println();
		
		// declare, construct and initialize an array in one statement
		int[] ints2 = new int[] {10, 20, 30};
		for(int i : ints2) {
			System.out.printf("%d ", i);
		}
		System.out.println();
		
		// declare, construct and initialize an array in one statement with shorthand
		int[] ints3 = {10, 20, 30};
		System.out.print("ints3: ");
		for(int i : ints3) {
			System.out.printf("%d ", i);
		}
		System.out.println();		
		
		// Create an empty array
		int[] ints4 = {};
		System.out.println("Empty array, ints4: " + Arrays.toString(ints4));
		// or
		int[] ints5 = new int[0];
		System.out.println("Empty array, ints5: " + Arrays.toString(ints5));
		
		// Creating Array of object data-types
		Student[] students = new Student[3];
		students[0] = new Student(980001, "Ana", LocalDate.of(2001, 1, 31), 3.9f);
		students[1] = new Student(980002, "Bob", LocalDate.of(2002, 2, 22), 3.6f);
		students[2] = new Student(980003, "Cris", LocalDate.of(2003, 3, 3), 3.8f);
		for(Student s : students) {
			System.out.printf("%s\n", s);
		}
		System.out.println("Or");
		// Or
		Student[] students2 = {
				new Student(980001, "Ana", LocalDate.of(2001, 1, 31), 3.9f),
				new Student(980002, "Bob", LocalDate.of(2002, 2, 22), 3.6f),
				new Student(980003, "Cris", LocalDate.of(2003, 3, 3), 3.8f)
		};
		for(Student s : students2) {
			System.out.printf("%s\n", s);
		}
		
		// Array length property
		System.out.printf("students array length is: %d", students.length);
		System.out.println();
		
		// Iterate array elements using the length property
		for(int i=0; i < students.length; i++) {
			System.out.printf("%s\n", students[i]);
		}
		System.out.println();
		
		// Copying elements of an array into a new array
		// Method 1 - Using Arrays.copyOf
		int[] extendedInts = Arrays.copyOf(ints, 2 * ints.length);
		for(int i : extendedInts) {
			System.out.printf("%d ", i);
		}
		System.out.println("\nOr");
		
		// Copying elements of an array into a new array
		// Method 2 - Using System.arrayCopy
		int[] extendedInts2 = new int[2*ints.length];
		System.arraycopy(ints, 0, extendedInts2, 0, ints.length);
		for(int i : extendedInts2) {
			System.out.printf("%d ", i);
		}
		System.out.println();
		
		System.out.println("Flattened nested array:");	
		// Nested arrays (aka multi-dimensional arrays)
		// e.g. Array of arrays
		int[][] nums = new int[3][];
		nums[0] = new int[]{10, 20, 30};
		nums[1] =  new int[]{40, 50};
		nums[2] = new int[]{60};
		for(int[] arrOfInts : nums) {
			for(int n : arrOfInts) {
				System.out.printf("%d ", n);
			}
		}
		System.out.println();
	}

}
