package edu.mum.cs.cs221.lesson1.javabasics;

import java.time.LocalDate;

class JavaBasicsApp {

	// Instance variables and the default values for primitive data-types - stored as value
	// built-in/primitive data types - (boolean, byte, short, char, int, long, float, double)  
	private int instanceVariablePrimitive;
	private int instanceVariablePrimitive1 = 1;
	
	// Instance variable and the default values for Object data-types - stored as reference to object
	// Wrapper classes - (Boolean, Byte, Short, Character, Integer, Long, Float, Double) 
	private Integer instanceVariableInteger;	
	private Integer instanceVariableInteger1 = 1;
	
	// Java class library classes
	private String instanceVariableString;
	private String instanceVariableStringTest = "Test";
	
	// User-defined classes
	private Student s1;
	private Student s2 = new Student(980001, "Ana", LocalDate.of(2001, 1, 31), 3.9f);
	
	public static void main(String[] args) {
		JavaBasicsApp app = new JavaBasicsApp();
		System.out.println("Default value int = " + app.instanceVariablePrimitive);
		System.out.println("Assigned value int = " + app.instanceVariablePrimitive1);
		
		System.out.println("Default value Integer = " + app.instanceVariableInteger);
		System.out.println("Assigned value Integer = " + app.instanceVariableInteger1);
		
		System.out.println("Default value String = " + app.instanceVariableString);
		System.out.println("Assigned value String = " + app.instanceVariableStringTest);		
		
		System.out.println("Default value Student = " + app.s1);
		System.out.println("Assigned value Student = " + app.s2);
		
		// Swapping values using temporary storage
		// 0.1 For primitive data types:
			int a = 1;
			int b = 2;
			System.out.println("a = " + a + "; and b = " + b);
			// swap
			int temp = a;
			a = b;
			b = temp;
			System.out.println("a = " + a + "; and b = " + b);
			
		// 0.2 For object data types e.g. String:
			String s1 = "Ana";
			String s2 = "Bob";
			System.out.println("s1 = " + s1 + "; and s2 = " + s2);
			// swap
			String tempString = s1;
			s1 = s2;
			s2 = tempString;
			System.out.println("s1 = " + s1 + "; and s2 = " + s2);
		// 0.3 For user-defined object types e.g. Student
			Student student1 = new Student(980001, "Ana", LocalDate.of(2001, 1, 31), 3.1f);
			Student student2 = new Student(980002, "Bob", LocalDate.of(2002, 2, 22), 3.2f);
			System.out.println("student1 = " + student1 + "; and student2 = " + student2);
			// swap
			Student tempStudent = student1;
			student1 = student2;
			student2 = tempStudent;
			System.out.println("student1 = " + student1 + "; and student2 = " + student2);
	}

}
