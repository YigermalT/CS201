/**
 * Student.java
 */
package edu.mum.cs.cs221.lesson1.javabasics;

import java.time.LocalDate;

public class Student {
    private int studentId;
    private String name;
    private LocalDate dateOfBirth;
    private float cgpa;
    
    public Student() { }
    
    public Student(String name) {
    	this(0, name, null, 0.0f);
    }
    
    public Student(int studentId, String name, LocalDate dateOfBirth, float cgpa) {
    	this.studentId = studentId;
    	this.name = name;
    	this.dateOfBirth = dateOfBirth;
    	this.cgpa = cgpa;
    }

    public int getStudentId() { return this.studentId; }
    public String getName() { return this.name; }
    public LocalDate getDateOfBirth() { return this.dateOfBirth; }
    public float getCGPA() { return this.cgpa; }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setCGPA(float cgpa) {
        this.cgpa = cgpa;
    }
    
    //TODO Add override for toString() method here
    @Override
    public String toString() {
    	String studentData = "{StudentId:" + studentId; 
        studentData += ", Name:" + name; 
        studentData += ", DateOfBirth:" + dateOfBirth; 
        studentData += ", CGPA: %.2f}";
    	return String.format(studentData, cgpa);
    }
}