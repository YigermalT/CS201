package edu.mum.cs.cs221.lesson1.generics.box_nongen;

class Box {
	private Object object1;
	private Object object2;
	
	Object getObject1() { return this.object1; }
	
	void setObject1(Object object1) {
		this.object1 = object1;
	}
	
	Object getObject2() { return this.object2; }
	
	void setObject2(Object object2) {
		this.object2 = object2;
	}
}
