package edu.mum.cs.cs221.lesson1.generics.box_nongen;

public class BoxNonGenApp {

	public static void main(String[] args) {
		
		Box box = new Box();
		box.setObject1(2);
		box.setObject2(3);
		
		Object o1 = box.getObject1();
		Object o2 = box.getObject2();
		System.out.printf("Multiplying, %s x %s = %s", o1, o2, (int)o1 * (int)o2 );
		System.out.println();

	}

}
