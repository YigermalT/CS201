package edu.mum.cs.cs221.lesson1.generics;

public class Container<V> {
	private V value;
	
	public void put(V value) {
		this.value = value;
	}
	
	public V get() {
		return value;
	}
}
