package edu.mum.cs.cs221.lesson1.generics.pairexamples;

public class Util {
	
    public static <K, V> boolean compare(SimplePair<K, V> p1, SimplePair<K, V> p2) {
        return (Boolean)(p1.getKey().equals(p2.getKey()) &&
               p1.getValue().equals(p2.getValue()));
    }
    
    @SuppressWarnings("unused")
	public static void main(String[] args) {
    	
    	SimplePair<Integer, String> p1 = new SimplePair<>(1, "apple");
    	SimplePair<Integer, String> p2 = new SimplePair<>(2, "pear");
    	//with type value
    	boolean areTheySame = Util.<Integer, String>compare(p1, p2);
    	   	
    	SimplePair<Integer, String> q1 = new SimplePair<>(1, "apple");
    	SimplePair<Integer, String> q2 = new SimplePair<>(2, "pear");
    	//without type value
    	boolean areTheySame2 = Util.compare(q1, q2);
    		
    }
	
}
