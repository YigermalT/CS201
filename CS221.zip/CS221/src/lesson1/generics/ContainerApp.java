package edu.mum.cs.cs221.lesson1.generics;

public class ContainerApp {

	
public static void main(String[] args) {

// Integer Type
		Container<Integer> c = new Container<Integer>();

//Container<Integer> c = new Container<>(); 
// Can use the Diamond notation and type inference
		
c.put(25);
		
int x = c.get();
		
System.out.println(x);


//String Type
		Container<String> c1 = new Container<String>();
		
//Container<String> c1 = new Container<>();
// Using the Diamond notation


c1.put("Hello World");
		
String out1 = c1.get();
	
System.out.println(out1);
		

	
}

}
