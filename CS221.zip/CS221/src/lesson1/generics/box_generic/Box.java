package edu.mum.cs.cs221.lesson1.generics.box_generic;

class Box<T, U> {
	private T t;
	private U u;
	
	T getT() { return this.t; }
	U getU() { return this.u; }
	
	void setT(T t) {
		this.t = t;
	}
	
	void setU(U u) {
		this.u = u;
	}
}
