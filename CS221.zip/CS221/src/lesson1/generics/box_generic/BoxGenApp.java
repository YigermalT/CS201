package edu.mum.cs.cs221.lesson1.generics.box_generic;

class BoxGenApp {

	public static void main(String[] args) {
		
		Box<Integer, Integer> box = new Box<>(); // Using the Diamond notation, as type is inferred
		box.setT(2);
		//box.setT("2"); Compile-error
		box.setU(3);
		
		Integer t = box.getT();
		Integer u = box.getU();
		
		System.out.printf("Multiplying, %s x %s = %s", t, u, t * u );

	}

}
