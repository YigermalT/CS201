package lesson7.createhashtable;

import java.util.LinkedList;

public class MyHashtableFirstTry {
	
	private static final int INITIAL_SIZE = 20;
	private int tableSize;
	private LinkedList[] table; 

	public MyHashtableFirstTry() {
		this(INITIAL_SIZE);
	}
	
	public MyHashtableFirstTry(int tableSize) {
		this.tableSize = tableSize;
		table = new LinkedList[tableSize];
	}
	
	// FIRST TRY (needs to be fixed -- see SECOND_TRY, next)
	public void put(Object key, Object value) {
		//disallow null keys
		if(key==null) return;
		//get the "big" integer corresponding to the object
		//assumes key is not null
		int hashcode = key.hashCode();
			
		//compress down to a table slot
		int hash = hash(hashcode);
			
		//put the value and the key into an Entry object
		//which will be placed in the table in the
		//slot (namely, hash)
		//allows a null value
		Entry e = new Entry(key,value);
			
		// now place it in the table
		if(table[hash] == null){
			table[hash] = new LinkedList();
		}
		table[hash].add(e);
	}
	
	private int hash(int bigNum) {
		return bigNum % tableSize;
	}

	private class Entry {
		Object key;
		Object value;
		
		Entry(Object key, Object value) {
			this.key = key;
			this.value = value;
		}
		
		public String toString(){
			return key.toString()+"->"+value.toString();
		}
	}
}
