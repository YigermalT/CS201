package cs221.datastructures.lists.linkedlists.singlelinkedlist;

class SingleLinkedListDemoApp {

	public static void main(String[] args) {
		SingleLinkedList<Integer> list = new SingleLinkedList<>();
		System.out.println(list);
		
		list.addFirst(3);
		list.addFirst(2);
		list.addFirst(1);
		System.out.println(list);
	}

}
