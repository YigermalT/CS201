package cs221.datastructures.lists.arraylist;
/**
 * ArrayList.java
 * 
 * @author okalu
 */
class ArrayList<E> {
	private static final int INITIAL_CAPACITY = 1; 
	private E[] data;
	private int capacity;
	private int size;
	
	@SuppressWarnings("unchecked")
	ArrayList() {
		this.capacity = INITIAL_CAPACITY;
		this.data = (E[]) new Object[INITIAL_CAPACITY];
		this.size = 0;
	}
	/**
	 * Adds a new element to the list
	 */
	public void add(E e) {
		if (size >= capacity) {
			reallocate();
		}
		data[size] = e;
		size = size + 1;
	}
	
	@SuppressWarnings("unchecked")
	private void reallocate() {
		capacity = 2 * capacity;
		E[] newData = (E[]) new Object[capacity];
//		int i = 0;
//		for(E e : data) {
//			newData[i] = e;
//			i = i + 1;
//		}
		for (int i = 0; i < data.length; i++) {
			newData[i] = data[i];
		}
		data = newData;
	}
	/**
	 * Returns the element at position index.
	 * @param index
	 * @return element at index
	 */
	public E get(int index) {
		if (index >= size) {
			throw new IndexOutOfBoundsException("Error: Invalid index - " + index);
		}
		E result = data[index];
		return result;
	}
	
	@Override
	public String toString() {
		String result = "[";
//		for(int i = 0; i < size; i++) {
//			result += data[i];
//		}
		int count = 0;
		if(size > 0) {
			for(E e : data) {
				String comma = (count < size-1) ? ", " : "";
				result += e.toString() + comma;
				count++;
			}
		}
		result += "]";
		return result;
	}	
}
