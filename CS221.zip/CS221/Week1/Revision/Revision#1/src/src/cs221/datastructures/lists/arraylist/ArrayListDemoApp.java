package cs221.datastructures.lists.arraylist;

class ArrayListDemoApp {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		System.out.println(list);
		
		list.add(1);
		System.out.println(list);
		list.add(2);
		System.out.println(list);
		System.out.println(list.get(3));
	}
}
