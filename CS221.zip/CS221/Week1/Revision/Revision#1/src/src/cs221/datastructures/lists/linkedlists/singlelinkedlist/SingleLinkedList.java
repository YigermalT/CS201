package cs221.datastructures.lists.linkedlists.singlelinkedlist;
/**
 * SingleLinkedList.java
 * 
 * @author okalu
 *
 */
class SingleLinkedList<E> {
	private Node<E> head; // firstNode, beginnerNode, etc.
	private int size;
	
	SingleLinkedList() {
		this.head = null; // Alternatively, this.head = new Node();
		this.size = 0;
	}
	
	/**
	 * Adds the data into list as the first
	 */
	public void addFirst(E data) {
//		Node<E> temp = new Node<>(data, head);
//		head = temp;
		head = new Node<>(data, head); // This is very kool, sophisticated and elegant
		// Alternative way to do this is:
		// 1: TODO - you try it here!
		
		size++;
	}
	
	/**
	 * Returns a String representation of the list,
	 * in the format, [e1, e2, e3]
	 */
	// 2: TODO - Add the small change in this code to format the list data as required.
	public String toString() {
		String result = "[";
		Node<E> currentNode = head;
		if(size > 0) { // if (currentNode != null)
			while (currentNode != null) {
				result += currentNode.data;
				currentNode = currentNode.next;
			}
		}
		result += "]";
		return result;
	}
	
	/**
	 * Returns the number of elements in the list
	 * @return
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Node for the Single-LinkedList, implemented
	 * here as a private static nested class, because
	 * it will only be used for the class and also it
	 * does not need to access any variable in the 
	 * SingleLinkedList outer class. 
	 * @author okalu
	 *
	 * @param <E>
	 */
	private static class Node<E> {
		private E data;
		private Node<E> next;
		
		
		private Node() { }
		
		private Node(E data) {
			this.data = data;
			this.next = null;
		}
		
		// Very useful for this style implementation e.g. addFirst, addLast
		private Node(E data, Node<E> next) {
			this.data = data;
			this.next = next;
		}
		
	}
}


