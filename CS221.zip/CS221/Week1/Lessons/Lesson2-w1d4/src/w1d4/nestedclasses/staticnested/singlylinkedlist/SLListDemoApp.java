/**
 * SLListDemoApp.java
 * 
 * A simple Console App to show the use of and demo
 * for the SinglyLinkedList.
 * 
 * @author Obinna A. Kalu
 * @since Sat 2018-04-14
 */

package w1d4.nestedclasses.staticnested.singlylinkedlist;

import java.time.LocalDate;

import w1d4.nestedclasses.staticnested.singlylinkedlist.model.Student;

class SLListDemoApp {

    public static void main(String[] args) {
        System.out.println("\nHello SinglyLinkedList!!!");

        SinglyLinkedList<Integer> nums = new SinglyLinkedList<>();
        System.out.println(nums);
        nums.add(1);
        System.out.println(nums);
        nums.add(2);
        System.out.println(nums);
        nums.add(3);
        System.out.println(nums);
        nums.add(4);
        System.out.println(nums);
        nums.add(5);
        System.out.println(nums);

        SinglyLinkedList<Student> students = new SinglyLinkedList<>();
        System.out.println(students);
        students.add(new Student(101L, "Adam", "Bostock", LocalDate.of(2018, 2, 25)));
        students.add(new Student(102L, "Brianna", "Cobello", LocalDate.of(2018, 3, 7)));
        students.add(new Student(103L, "Carlos", "Demerino", LocalDate.of(2018, 4, 13)));
        System.out.println(students);

        SinglyLinkedList<Integer> nums2 = new SinglyLinkedList<>(1, 2);
        nums2.add(3);
        nums2.add(4);
        nums2.add(5);
        nums2.add(6);
        System.out.println(nums2);
    }
}