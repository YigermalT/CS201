/**
 * SinglyLinkedList.java
 * 
 * An implementation of a classic, generic Single-LinkedList
 * type data structure; with support for data of any type, E.
 * 
 * @author Obinna A. Kalu
 * @since Sat 2018-04-14
 */

package w1d4.nestedclasses.staticnested.singlylinkedlist;

class SinglyLinkedList<E> {
    private SLListNode<E> head;
    private SLListNode<E> tail;
    private boolean empty;
    private int size;

    SinglyLinkedList() { 
        this.head = this.tail = null;
        this.empty = true;
        this.size = 0;
    }

    SinglyLinkedList(E headData) {
        this.head = this.tail = new SLListNode<>(headData);
        this.empty = false;
        this.size = 1;
    }

    SinglyLinkedList(E headData, E tailData) {
        this.head = new SLListNode<>(headData);
        this.tail = new SLListNode<>(tailData);
        this.head.next = this.tail;
        this.empty = false;
        this.size = 2;
    }

    boolean isEmpty() { return this.empty; }
    int getSize() { return this.size; }

    // Operations
    void add(E data) {
        SLListNode<E> newNode = new SLListNode<>(data);
        if(this.empty) {
            this.head = this.tail = newNode;
            this.empty = false;
            this.size = 1;
        } else {
            this.tail.next = newNode;
            this.tail = newNode;
            ++this.size;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        if(!this.empty) {            
            SLListNode<E> currNode = this.head;
            while(currNode != null) {
                sb.append(currNode.data.toString());
                if(currNode.next != null)
                    sb.append(", ");
                currNode = currNode.next;
            }
        } 
        sb.append("]");  
        return sb.toString();
    }

    private static final class SLListNode<E> {
        private E data;
        private SLListNode<E> next;

        private SLListNode(E data) {
            this.data = data;
        }
    }
}