package w1d4.nestedclasses.member.inner.integerarraylist;
/**
 * An array-backed list for Integers
 * 
 * @author O. Kalu
 * @since Wed 2018-2-21
 */
public class IntegerArrayList {
	private int capacity = 2;
	private int size;
	private Integer[] data;
	
	public IntegerArrayList() {
		this.data = new Integer[capacity];
		this.size = 0;
	}
	/**
	 * Adds the new Integer element, i, 
	 * to the list 
	 * @param i
	 */
	public void add(Integer i) {
		if(this.size < data.length) {
			data[size++] = i;
		} else {
			resize();
			data[size++] = i;
		}
	}
	
	private void resize() {
		int dataLength = this.data.length;
		Integer[] newData = new Integer[2 * dataLength];
		System.arraycopy(data, 0, newData, 0, dataLength);
		this.data = newData;
		this.capacity = newData.length;
	}
	
	public Integer get(int index) {
		Integer i = null;
		if(index >= 0 && index < size) {
			i = data[index];
		}
		return i;
	}
	/**
	 * Prints-out all the elements in the list.
	 */	
	public void printAll() {
		if(size > 0) {
			for(int i=0; i < size; i++) {
				System.out.printf("%d ", data[i]);
			}
		} else {
			System.out.printf("List is empty");
		}
		System.out.println();
	}
	
	public IntegerArrayListIterator getIterator() {
		return new IntegerArrayListIterator();
	}
	
	/**
	 * Reverses the order of the elements
	 * in the list, such that the first
	 * becomes the last and the last becomes
	 * the first.
	 */
	public void reverse() {
		// 1: DONE (5 points)
		if(size > 1) {
            // Make an array of same capacity
            Integer[] newArray = new Integer[this.capacity];
            // Transfer all existing elements in reverse order
            int counter = this.size - 1;
            for (int i = 0; i < this.size; i++) {
                newArray[counter--] = this.data[i];
            }
            this.data = newArray;
		}
	}
	
	class IntegerArrayListIterator {
		private int currentIndex;
		
		IntegerArrayListIterator() {
			this.currentIndex = 0;
		}
		/**
		 * Returns true if the iteration has more elements.
		 * @return true, if there is a next. Otherwise, false.
		 */		
		public boolean hasNext() {
			// 2: DONE (5 points)
			boolean nextExists = this.currentIndex < size;
			return nextExists;
		}
		/**
		 * Returns the next element in the iteration, if one exists.
		 * Otherwise, returns null.
		 * @return the next element
		 */		
		public Integer next() {
			// 3: DONE (5 points)
			Integer nextInt = null;
			if(hasNext()) {
				nextInt = data[currentIndex];
				currentIndex++;
			}
			return nextInt;
		}
		/**
		 * Returns the next element in the iteration, if one exists
		 * without advancing the cursor. Otherwise, returns null.
		 * @return the next element
		 */		
		public Integer peek() {
			// 4: DONE (5 points)
			Integer peekedInt = null;
			if(hasNext()) {
				peekedInt = data[currentIndex];
			}
			return peekedInt;
		}
	}
}
