package w1d4.nestedclasses.anonymous.inner.comparator;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;

class StudentsComparatorApp {

	public static void main(String[] args) {
		// Creating an array of Students
		Student[] students = new Student[3];
		students[0] = new Student(980001, "Ana", LocalDate.of(2001, 1, 31), 3.9f);
		students[1] = new Student(980002, "Bob", LocalDate.of(2002, 2, 22), 3.6f);
		students[2] = new Student(980003, "Cris", LocalDate.of(2003, 3, 3), 3.8f);
		
		// Uses Comparator defined via an anonymous inner class here
		Arrays.sort(students, new Comparator<Student>() {

			@Override
			public int compare(Student s1, Student s2) {
				if(s1.getCGPA() < s2.getCGPA()) {
					return -1;
				} else if(s1.getCGPA() > s2.getCGPA()) {
					return 1;
				}
				return 0;
			}			
		});
		
		Arrays.stream(students).forEach(System.out::println);
		//System.out.println(Arrays.toString(students));

	}

}
