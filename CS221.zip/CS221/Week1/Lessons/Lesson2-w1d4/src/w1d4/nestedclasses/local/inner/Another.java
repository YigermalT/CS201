package w1d4.nestedclasses.local.inner;

public class Another {
	int z = 4;

	int myMethod(int y, final int x) {
		int w = 3;
		final int u = 4;
		class LocalInner {
			int innerVble = 8;

			private int inner() {
				int newInt = z + innerVble;
//				y = 0; // compiler error -- y is effectively final
//				x = 1; // compiler error -- x is effectively final
				newInt += y; 
				newInt += w; 
				newInt += u;
				newInt += x;
				return newInt;
			}
		}
		//LocalInner li = new LocalInner();
		return new LocalInner().inner();
	}
	
	public static void main(String... args) {
		Another app = new Another();
		System.out.println("Call myMethod..." + app.myMethod(1, 2));
		
	}
}
