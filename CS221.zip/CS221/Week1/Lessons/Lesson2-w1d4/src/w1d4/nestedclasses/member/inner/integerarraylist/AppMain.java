package w1d4.nestedclasses.member.inner.integerarraylist;

import w1d4.nestedclasses.member.inner.integerarraylist.IntegerArrayList.IntegerArrayListIterator;

public class AppMain {

	public static void main(String[] args) {
		
		IntegerArrayList list = new IntegerArrayList();
		
		IntegerArrayListIterator it0 = list.getIterator();
		System.out.println(it0.hasNext()); // prints: false
		
		list.add(1);
		System.out.println(list.get(0)); // prints: 1
		System.out.println(it0.hasNext()); // prints: true
		list.add(2);
		list.add(3);	
		list.add(4);		
		list.printAll(); // prints: 1 2 3 4
		
		list.reverse();
		list.printAll(); // prints: 4 3 2 1
		
		IntegerArrayListIterator it = list.getIterator();
		while(it.hasNext()) { // prints: 4 3 2 1
			System.out.printf("%d ", it.next());
		}
		System.out.println();
		
		// Re-reverse the list
		list.reverse();
		list.printAll(); // prints: 1 2 3 4
		
		IntegerArrayListIterator it2 = list.getIterator();
		System.out.println(it2.hasNext()); // prints: true
		System.out.println(it2.next()); // prints: 1
		System.out.println(it2.peek()); // prints: 2
		System.out.println(it2.peek()); // prints: 2
		System.out.println(it2.next()); // prints: 2
		System.out.println(it2.hasNext()); // prints: true
		System.out.println(it2.next()); // prints: 3
		System.out.println(it2.peek()); // prints: 4
		System.out.println(it2.hasNext()); // prints: true
		System.out.println(it2.next()); // prints: 4
		System.out.println(it2.hasNext()); // prints: false
		System.out.println(it2.peek()); // prints: null
		System.out.println(it2.next()); // prints: null
	}

}
