/**
 * Student.java
 * 
 * A basic model class representing a Student
 * 
 * @author Obinna A. Kalu
 * @since Sat 2018-04-14
 */

package w1d4.nestedclasses.staticnested.singlylinkedlist.model;

import java.time.LocalDate;

public final class Student {
    private final long studentId;
    private final String firstName;
    private final String lastName;
    private final LocalDate dateOfAdmission;

    public Student() { 
        this.studentId = Long.MIN_VALUE;
        this.firstName = "";
        this.lastName = "";
        this.dateOfAdmission = null;
    }

    public Student(long studentId, String firstName, String lastName, LocalDate dateOfAdmission) {
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfAdmission = dateOfAdmission;
    }

    public long getStudentId() { return this.studentId; }
    public String getFirstName() { return this.firstName; }
    public String getLastName() { return this.lastName; }
    public LocalDate getDateOfAdmission() { return this.dateOfAdmission; }

    @Override
    public String toString() {
        return String.format("\n  {StudentId: %d, FirstName: %s, LastName: %s, DateOfAdmission: %s}", 
            this.studentId, this.firstName, this.lastName, this.dateOfAdmission);
    }
 }