/**
 * SinglyLinkedList.java
 */
package w1d4.mylinkedlists.com.obinna.datastructures.list.linkedlist.singlylinkedlistwithnestednodeclass;

/**
 * My demo implementation of a SinglyLinkedList,
 * with support for reversing the order of elements
 * in the list.
 * 
 * @author okalu
 * @since 2017-10-15
 *
 * @param <E>
 */
public class SinglyLinkedList<E> {
    private ListNode<E> head;
    private ListNode<E> tail;
    private int size;
    private boolean empty;

    public SinglyLinkedList() {
        this(null, null, 0, true);
    }

    public SinglyLinkedList(ListNode<E> head) {
        this(head, head, 1, false);
    }

    public SinglyLinkedList(ListNode<E> head, ListNode<E> tail) {
        this(head, tail, 2, false);
        this.head.next = tail;
    }

    private SinglyLinkedList(ListNode<E> head, ListNode<E> tail, int size, boolean empty) {
        this.head = head;
        this.tail = tail;
        this.size = size;
        this.empty = empty;
    }

    public ListNode<E> getHead() { return this.head; }
    public ListNode<E> getTail() { return this.tail; }
    public int getSize() { return this.size; }
    public boolean isEmpty() { return this.empty; }

    public void add(E newData) {
        ListNode<E> newNode = new ListNode<>(newData);
        if(this.empty) {
            this.head = this.tail = newNode;
            this.size = 1;
            this.empty = false;
        } else {
            this.tail.next = newNode;
            this.tail = newNode;
            this.size++;
        }
    }

    public void reverse() {
        if(this.size > 1) {
            ListNode<E> newNext = null;
            ListNode<E> currNode = this.head;
            //this.tail = currNode; // SetNewTail: Uncomment this line
            while(currNode != null) {
                ListNode<E> next = currNode.next;
                currNode.next = newNext;
                newNext = currNode;
                currNode = next;
            }
            /*
            As alternative to performing this head-and-tail swap,
            simply comment-out the following 3 lines which does the swap
            and uncomment the 2 lines marked, SetNewTail and SetNewHead,
            above and below respectively.
             */
            ListNode<E> temp = this.head;
            this.head = this.tail;
            this.tail = temp;
            //this.head = newNext; // SetNewHead: Uncomment this line
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        if(!this.empty) {
            ListNode<E> listNode = this.head;
            while(listNode != null) {
                sb.append(listNode.data);
                String delimiter = (listNode != this.tail) ? ", " : "]";
                sb.append(delimiter);
                listNode = listNode.next;
            }

        } else {
            sb.append("]");
        }
        return sb.toString();
    }

    private static final class ListNode<E> {
        ListNode<E> next;
        E data;

        ListNode(E data) {
            this(data, null);
        }

        ListNode(E data, ListNode<E> next) {
            this.data = data;
            this.next = next;
        }

        @Override
        public String toString() {
            return String.format("This is: %s. Next is: %s", this.data, this.next.data);
        }
    }
}
