package lab2.q2;

class OKArrayListDemoApp {

	public static void main(String[] args) {
		
    	OKArrayList<String> str = new OKArrayList<String>();
    	System.out.println("Initial capacity : " + str.getCapacity());
    	System.out.println("Size of the list : " + str.size());
    	System.out.println(str);
    	str.add("Java");
    	str.add("Data Structures");
    	System.out.println(str);
    	System.out.println("Size of the list : " + str.size());
    	str.add(1,"C#");
    	System.out.println(str);
    	System.out.println("Size of the list : " + str.size());
    	str.add("Design Pattern");
    	str.remove(1);    	
    	System.out.println(str);
    	System.out.println("Size of the list : " + str.size());
    	System.out.println("Index of C# : "+ str.indexOf("C#"));
    	System.out.println("Index of Java :"+ str.indexOf("Java"));
    	System.out.println("Element at the index 2 : " + str.get(2));
    	System.out.println("Set the value at the index 1 : " + str.set(1,"Software Engineering"));
    	
    	System.out.println(str); // ***

	}

}
