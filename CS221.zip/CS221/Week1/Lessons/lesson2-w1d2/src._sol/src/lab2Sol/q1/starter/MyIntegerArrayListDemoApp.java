/**
 * MyIntegerArrayListDemoApp.java
 * 
 */
package lab2.q1.starter;

class MyIntegerArrayListDemoApp {

	public static void main(String[] args) {
		MyIntegerArrayList list = new MyIntegerArrayList();
		System.out.println("A. " + list); // Prints: A. []
		
		list.add(1);
		System.out.println("B. " + list); // Prints: B. [1]
		
		list.add(2);
		list.add(3);	
		list.add(4);
		list.add(5);
		System.out.println("C. " + list); // Prints: C. [1, 2, 3, 4, 5]
		
		System.out.println("D. " + list.get(2)); // Prints: D. 3
		
		list.reverse();
		System.out.println("E. " + list); // Prints: E. [5, 4, 3, 2, 1]
		
		list.reverse();
		System.out.println("F. " + list); // Prints: F. [1, 2, 3, 4, 5]
		
		list.clear();
		System.out.println("G. " + list); // Prints: G. []
		
	}

}
