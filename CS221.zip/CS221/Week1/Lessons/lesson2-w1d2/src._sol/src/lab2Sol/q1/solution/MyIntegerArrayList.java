/**
 * MyIntegerArrayList.java
 * 
 * @author your-name
 * @since 2018-5-1
 */
package lab2.q1.solution;

/**
 * A special ArrayList for Integers only
 * 
 */
class MyIntegerArrayList {
	private int capacity = 2;
	private int size;
	private Integer[] data;
	
	MyIntegerArrayList() {
		this.data = new Integer[capacity];
		this.size = 0;
	}
	
	/**
	 * Adds the new Integer element, i, 
	 * to the list 
	 * @param i
	 */
	public void add(Integer i) {
		if(this.size < data.length) {
			data[size++] = i;
		} else {
			reallocate();
			data[size++] = i;
		}
	}
	
	private void reallocate() {
		int dataLength = this.data.length;
		Integer[] newData = new Integer[2*dataLength];
		System.arraycopy(data, 0, newData, 0, dataLength);
		this.data = newData;
		this.capacity = newData.length;
	}
	
    /**
     * Returns the element at the specified position in this list.
     *
     * @param  index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException 
     */
	public Integer get(int index) {
		Integer i = null;
		if(index >= 0 && index < size) {
			i = data[index];
		}
		return i;
	}
	
	/**
	 * Reverses the order of the elements
	 * in the list, such that the first
	 * becomes the last and the last becomes
	 * the first.
	 */
	public void reverse() {
		// 1: DONE (5 points)
		if(size > 1) {
            // Make an array of same capacity
            Integer[] newArray = new Integer[this.capacity];
            // Transfer all existing elements in reverse order
            int counter = size - 1;
            for (int i = 0; i < size; i++) {
                newArray[counter--] = data[i];
            }
            this.data = newArray;
		}
	}
	
    /**
     * Removes all of the elements from this list.  The list will
     * be empty after this method is called.
     */
	void clear() {
        // Set all elements to null; to enable GC to reclaim
        for (int i = 0; i < size; i++)
            data[i] = null;
        size = 0;
	}
	
	/**
     * Returns a string representation of the list,
     * showing all the elements it contains,
     * in the format, [e1, e2, e3]. If the list
     * is empty, it returns, [].
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		for(int i = 0; i < size; i++) {
			String dataFormat = (size - i > 1) ? "%d, " : "%d";
			sb.append(String.format(dataFormat, data[i]));
		}
		sb.append("]");
		return sb.toString();
	}
	
	/*
	 * Other interesting methods to implement:
	 * 
	 * 1. Integer remove(int index).
	 * 2. boolean remove(Integer i).
	 * 3. void insert(int index, Integer i).
	 * 4. void trimToSize();
	 * 5. boolean contains(Integer i).
	 * 6. int indexOf(Object obj).
	 * 7. void replace(int index, Integer i)
	 */

}
