/**
 * MyIntegerArrayList.java
 * 
 * @author your-name
 * @since 2018-5-1
 */
package lab2.q1.starter;

/**
 * A special ArrayList for Integers only
 * 
 */
class MyIntegerArrayList {
	private int capacity = 2;
	private int size;
	private Integer[] data;
	
	MyIntegerArrayList() {
		// 1: TODO (5 points)
	}
	
	/**
	 * Adds the new Integer element, i, 
	 * to the list 
	 * @param i
	 */
	public void add(Integer i) {
		// 2: TODO (5 points)
	}
	
    /**
     * Returns the element at the specified position in this list.
     *
     * @param  index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException 
     */
	public Integer get(int index) {
		// 3: TODO (5 points)
		return null;
	}
	
	/**
	 * Reverses the order of the elements
	 * in the list, such that the first
	 * becomes the last and the last becomes
	 * the first.
	 */
	public void reverse() {
		// 4: TODO (5 points)
	}
	
    /**
     * Removes all of the elements from this list.  The list will
     * be empty after this method is called.
     */
	void clear() {
		// 5: TODO (5 points)
	}
	
	/**
     * Returns a string representation of the list,
     * showing all the elements it contains,
     * in the format, [e1, e2, e3]. If the list
     * is empty, it returns, [].
	 */
	@Override
	public String toString() {
		// 6: TODO (5 points)
		return "";
	}
}
