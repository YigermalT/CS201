package lab2.q2;

import java.util.Arrays;
import java.util.Collection;

public class OKArrayList<E> {
	
    // Data Fields
    /** The default initial capacity */
    private static final int INITIAL_CAPACITY = 10;
    
    /** The underlying data array */
    private Object[] theData;
    //private E[] theData;
    
    /** The current capacity */
    private int capacity = 0;
    
    /** The current size */
    private int size = 0; // Note: 0 <= size <= capacity
    
    /** Indicates whether the list is empty or not */
    private boolean empty;
    
    /** Indicates whether the list is full or not */
    private boolean full;
    
    /**
     * Construct an empty OKArrayList with the default
     * initial capacity
     */
    @SuppressWarnings("unchecked")
	public OKArrayList() {
        capacity = INITIAL_CAPACITY;
        theData = new Object[capacity];
        //theData = (E[]) new Object[capacity];
        //theData = new E[]; //Note: This gives compile error, since it is not possible to create generic array of E
    }
    
    /**
     * Construct an empty OKArrayList with a specified initial capacity
     * @param capacity The initial capacity
     * @throws IllegalArgumentException if the specified initial capacity
     * 			is negative
     */
    public OKArrayList(int capacity) {
    	if(capacity >= 0) {
    		this.capacity = capacity;
    		theData = new Object[capacity];
    	} else {
    		throw new IllegalArgumentException("Capacity must be a non-negative integer");
    	}
    }
    
    /**
     * Returns the number of elements in this list.
     *
     * @return the number of elements in this list
     */
    public int size() {
        return size;
    }
    
    public int getCapacity() {
    	return capacity;
    }
    
    /**
     * Returns the element at the specified position in this list.
     *
     * @param  index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException 
     */
    @SuppressWarnings("unchecked")
	public E get(int index) {
    	if (index >= size)
            throw new IndexOutOfBoundsException("Index is out-of-bounds. index: " + index);

        return (E) theData[index];
    }
    
    /**
     * Replaces the element at the specified position in this list with
     * the specified element.
     *
     * @param index index of the element to replace
     * @param element element to be stored at the specified position
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException 
     */
    @SuppressWarnings("unchecked")
	public E set(int index, E element) {
    	if (index >= size)
            throw new IndexOutOfBoundsException("Index is out-of-bounds. index: " + index);
        E oldValue = (E) theData[index];
        theData[index] = element;
        return oldValue;
    }
    
    /**
     * Adds the specified element to the end of this list.
     *
     * @param e element to be appended to this list
     * @return true, if the list changed as a result of this
     */
    public boolean add(E e) {
    	if(size == capacity) {
    		resize();
    	}
    	theData[size] = e;
    	size++;
    	return true;
    }
    
    /**
     * Inserts the specified element at the specified position in this
     * list. Shifts the element currently at that position (if any) and
     * any subsequent elements to the right (adds one to their indices).
     *
     * @param index index at which the specified element is to be inserted
     * @param element element to be inserted.
     */
    public void add(int index, E element) {
		if (index > size || index < 0)
			throw new IndexOutOfBoundsException("Index is out-of-bounds. index: " + index);
		if (size == capacity) {
			resize();
		}
		
		// shift every element including index to the last, one place to the right 
		for (int i = size; i > index; i--) {
		  theData[i] = theData[i-1];
		}
		// Alternatively, use System.arraycopy or Arrays.copyRange
		//System.arraycopy(theData, index, theData, index+1, size-index);

		// insert the element
		theData[index] = element;
		size++;   	
    }
    
    /**
     * Allocates a new, bigger array to hold the data
     */
    private void resize() {
    	if (capacity == 0)
    		++capacity;
    	this.capacity = 2 * capacity;
    	this.theData = Arrays.copyOf(theData, capacity);
    }
    
    /**
     * Removes the element at the specified position in this list.
     * Shifts any subsequent elements to the left (subtracts one from their
     * indices).
     *
     * @param index the index of the element to be removed
     * @return the element that was removed from the list
     * @throws IndexOutOfBoundsException
     */
    @SuppressWarnings("unchecked")
	public E remove(int index) {
    	if (index >= size)
            throw new IndexOutOfBoundsException("Index is out-of-bounds. index: " + index);
        E removedValue = (E) theData[index];
        // Shift elements one place back
        // Option 1:
        int numMoved = size - index - 1;
        if (numMoved > 0) // If element being removed was not the last one
        	System.arraycopy(theData, index+1, theData, index, numMoved);
        // Option 2:
        // Alternatively, check if needed then shift all data to the left, upto index position
//        if(index < size-1) { // If element being removed was not the last one
//        	for (int i = index + 1; i < size; i++) {
//        		theData[i-1] = theData[i];
//        	}
//        }
        
        size--;
        theData[size] = null; // set this to null, so that GC can reclaim and avoid memory-leaks

        return removedValue;
    }
    
    /**
     * Removes the first occurrence of the specified element from this list,
     * if it is present.  If the list does not contain the element, it is
     * unchanged. 
     * 
     * @param e element to be removed from this list, if present
     * @return true if this list contained the specified element
     */
    public boolean remove(Object e) {
        if (e == null) {
            for (int index = 0; index < size; index++)
                if (theData[index] == null) {
                    quickRemove(index);
                    return true;
                }
        } else {
            for (int index = 0; index < size; index++)
                if (e.equals(theData[index])) {
                    quickRemove(index);
                    return true;
                }
        }
        return false;
    }
    
    private void quickRemove(int index) {
        int numMoved = size - index - 1;
        if (numMoved > 0) // If element being removed was not the last one
            System.arraycopy(theData, index+1, theData, index, numMoved);
        theData[--size] = null; // set this to null, so that GC can reclaim and avoid memory-leaks
    }
       
    /**
     * Creates an OKArrayList and populates it with data from the specified feeder-array
     * @param feeder_array the specified feeder-array
     */
    public OKArrayList(E[] feeder_array) {
    	//DONE - In-class Exercise
    	if(feeder_array.length > 0) {
    		this.size = feeder_array.length;
    		this.capacity = 2 * size;
    		this.theData = Arrays.copyOf(feeder_array, capacity);
    	} else {
    		this.theData = feeder_array;
    	}
    }
    
    /**
     * Trims the capacity of this OKArrayList instance to be the
     * list's current size.  An application can use this operation to minimize
     * the storage of an OKArrayList instance.
     */
    public void trimToSize() {
    	//DONE - In-class Exercise
        if (size < theData.length) {
            theData = (size == 0) ? new Object[] {} : Arrays.copyOf(theData, size);
        }
    }
    
    /**
     * Returns true if the list is empty (i.e. contains no elements)
     * @return true, if this list is empty and contains no elements
     */
    public boolean isEmpty() {
    	//DONE - In-class Exercise
    	return size == 0;
    }
    
    /**
     * Returns true if the list is full (i.e. contains no empty slot)
     * @return true, if this list is full and contains no element slot)
     */
    public boolean isFull() {
    	//DONE - In-class Exercise
    	return size == capacity;
    }  
    
    /**
     * Returns true if this list contains the specified element.
     * More formally, returns true if and only if this list contains
     * at least one element, e, such that
     * (o==null ? e==null : o.equals(e)).
     *
     * @param o element whose presence in this list is to be tested
     * @return true, if this list contains the specified element
     */
    public boolean contains(Object o) {
    	//DONE - In-class Exercise
    	return indexOf(o) >= 0;
    }
    
    /**
     * Returns the index of the first occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     * or -1 if there is no such index.
     * 
     * @param element the element to search for
     * @returns The index of the first occurrence of the specified element
     *          or -1 if this list does not contain the element
     */
    public int indexOf(Object element) {
        if (element == null) {
            for (int i = 0; i < size; i++)
                if (theData[i] == null)
                    return i;
        } else {
            for (int i = 0; i < size; i++)
                if (element.equals(theData[i]))
                    return i;
        }
        return -1;
    }
    
    /**
     * Returns an array containing all of the elements in this list
     * in proper sequence (from first to last element).
     * 
     * The returned array will be "safe" in that no references to it are
     * maintained by this list.  (In other words, this method must allocate
     * a new array).  The caller is therefore, free to modify the returned array.
     *
     * @return an array containing all of the elements in this list in
     *         proper sequence
     */
    public Object[] toArray() {
    	//DONE - In-class Exercise
    	return Arrays.copyOf(theData, size);
    }
    
    /**
     * Removes all of the elements from this list.  The list will
     * be empty after this call returns.
     */
    public void clear() {
    	//DONE - In-class Exercise
        // Set all elements to null; to enable GC to reclaim
        for (int i = 0; i < size; i++)
            theData[i] = null;

        size = 0;
    }
    
    /**
     * Returns a string representation of this list.
     * In the format, [e1, e2, e3]
     */
    @Override
    public String toString() {
		StringBuilder sb = new StringBuilder("[");
		for(int i = 0; i < size; i++) {
			String dataFormat = (size - i > 1) ? "%s, " : "%s";
			sb.append(String.format(dataFormat, theData[i]));
		}
		sb.append("]");
		return sb.toString();
    }
    
}
