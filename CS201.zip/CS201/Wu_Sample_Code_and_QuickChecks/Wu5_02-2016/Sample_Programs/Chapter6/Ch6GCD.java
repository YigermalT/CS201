/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 6 Sample Program: Finding the Greatest Common Divisor

    File: Ch6GCD.java

*/


class Ch6GCD {
    
    
    public static void main(String[] args)  {

        Ch6GCD tester = new Ch6GCD( );
        
        tester.start();
    }
    
    public Ch6GCD() {
        
    }
    
    public void start( ) {
        
        int num1 = gcd_bruteforce(32, 848);
        int num2 = gcd_do(32, 848);
        int num3 = gcd_LaH(32, 848);
        int num4 = gcd(32, 848);
        
        int num5 = gcd_recursive(32, 848);
        
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(num3);
        System.out.println(num4);
        
        System.out.println(num5);
    }
    
    
    public int gcd_bruteforce(int m, int n) {

        //assume m, n >= 1
    
        int last = Math.min(m, n);
    
        int gcd = 1;
        int i = 1;
    
        while (i <= last) {
    
            if (m % i == 0 && n % i == 0) {
    
                gcd = i;
            }
    
            i++;
        }
    
        return gcd;
    }
    
    
    public int gcd_do(int m, int n) {

        int r;
    
        do {
            
            r = n % m;
    
            n = m;
    
            m = r;
    
        } while (r != 0);
    
        return n; //NOTE: we�re returning n!
    }
    
    
    public int gcd_LaH(int m, int n) {

        int r;
    
        while (true) {
    
            r = n % m;
    
            if (r == 0) break;
    
            n = m;
    
            m = r;
        }
    
        return m;
    }
    
    
    public int gcd(int m, int n) {
        
        int r = n % m;

        while (r !=0) {
    
            n = m;
    
            m = r;
    
            r = n % m;
        }
    
        return m;
    }
    
    public int gcd_recursive(int m, int n) {

        int gcd;
    
        if (m == 0) { //test
            
            gcd = n;			//end case
        
        } else {
            
            gcd = gcd_recursive(n % m, m); //recursive case
        }
    
        return gcd;
    }
}