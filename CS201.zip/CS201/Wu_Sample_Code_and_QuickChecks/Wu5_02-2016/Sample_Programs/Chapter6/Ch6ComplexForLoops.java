/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 6 Sample Program: Complex For Loops

    File: Ch6ComplexForLoops.java

*/


import java.util.*;

class Ch6ComplexForLoops {

    public static void main( String[] args )  {


        int val, i, j;
        for (i = 0, j = 100, val = 0; i < 100 && j > 50; i++, j--) {
            val += i - j;
        }

        System.out.println("val = " + val);
        
        Scanner scanner = new Scanner(System.in);

        int sum, cnt, n;
        
        for (sum = 0, cnt = 0;
        
             cnt < 10;
             
             System.out.print("Enter number: "), 
             n = scanner.nextInt(),   
             sum += n,
             cnt++ ) {
        }

        System.out.println("sum = " + sum);
    }
}