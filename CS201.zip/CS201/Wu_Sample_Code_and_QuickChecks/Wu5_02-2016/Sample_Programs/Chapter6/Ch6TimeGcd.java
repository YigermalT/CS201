/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 6 Sample Program: Time the performance of gcd methods

    File: Ch6TimeGcd.java

*/

import java.util.*;

class Ch6TimeGcd {
    
    private static enum ComputationType {BRUTE_FORCE, EUCLID}
    
    private Scanner scanner;

    public static void main(String[] args)  {

        Ch6TimeGcd tester = new Ch6TimeGcd( );
        
        tester.start();
        
        System.exit(0);
    }
    
    public Ch6TimeGcd() {
        scanner = new Scanner(System.in);
    }
    
    public void start( ) {
        
        long bruteForceTime, euclidTime;
        int m, n;
        
        while (isContinue()) {
            
            m = getPositiveInteger( );
            n = getPositiveInteger( );

            //Time the brute force method
            bruteForceTime = timeMethod(m, n, ComputationType.BRUTE_FORCE);
            
            //Time the Euclidean method
            euclidTime = timeMethod(m, n, ComputationType.EUCLID);
            
            System.out.println("M: " + m);
            System.out.println("N: " + n);
            System.out.println("Brute Force Time: " + bruteForceTime);
            System.out.println("Euclidean Time:   " + euclidTime + "\n");
        }       
    }
    
    private long timeMethod(int m, int n, ComputationType type) {
        
        Date startTime, endTime;
        
        startTime = new Date();

        if (type == ComputationType.BRUTE_FORCE) {
            
            gcd_bruteforce(m, n);
            
        } else {
            
            gcd(m, n);
        }

        endTime = new Date();

        return (endTime.getTime() - startTime.getTime());
    }
            
    
    private int getPositiveInteger( ) {
        
        int input;

        while (true) {
        
            System.out.print("Enter positive integer (0 is okay):");
            input = scanner.nextInt();
        
            if (input >= 0) break;
            
            System.out.println("Input must be 0 or more");
        }
        
        return input;
    }
    
    private boolean isContinue( ) {
    
        String input;

        boolean response = false;

        System.out.print("Run test? ");

        input = scanner.next();

        if (input.equals("Y") || input.equals("y")) {
            response = true;
        }

        return response;
    }
    
    private int gcd_bruteforce(int m, int n) {

        //assume m, n >= 1
    
        int last = Math.min(m, n);
    
        int gcd = 1;
        int i = 1;
    
        while (i <= last) {
    
            if (m % i == 0 && n % i == 0) {
    
                gcd = i;
            }
    
            i++;
        }
    
        return gcd;
    }
    
    private int gcd(int m, int n) {
        
        int r = n % m;

        while (r !=0) {
    
            n = m;
    
            m = r;
    
            r = n % m;
        }
    
        return m;
    }
    
}