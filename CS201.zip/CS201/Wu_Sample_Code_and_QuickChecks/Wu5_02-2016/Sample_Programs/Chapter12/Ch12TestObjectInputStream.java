/*
    Introduction to OOP with Java (5thEd), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Illustrate the use of ObjectInputStream

    File: Ch12TestObjectInputStream.java
*/

import java.io.*;

class Ch12TestObjectInputStream {

    public static void main (String[] args) throws ClassNotFoundException,
                                                   IOException {

        //setup file and stream
        File              inFile  = new File("objects.dat");

        FileInputStream   inFileStream
                                  = new FileInputStream(inFile);

        ObjectInputStream inObjectStream
                                  = new ObjectInputStream(inFileStream);

        //read the Person objects from a file
        Person person;
        for (int i = 0; i < 10; i++) {
            person = (Person) inObjectStream.readObject();

            System.out.println(person.getName() + "     " +
                               person.getAge()  + "     " +
                               person.getGender());
        }

        //input done, so close the stream
        inObjectStream.close();
   }
}