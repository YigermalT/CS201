/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Test the read and write methods (Step 4)

    File: Step4/TestAddressBookFinal.java
*/

import java.io.*;

/**
 * This class is for testing the I/O operations of AddressBookStorage.
 * 
 */

class TestAddressBookFinal {

    public static void main(String[] args)throws IOException {
        
        TestAddressBookWrite writer = new TestAddressBookWrite(25);
        TestAddressBookRead  reader = new TestAddressBookRead( );

        writer.write("book.data");
        reader.read("book.data");

        reader.search( "Ms. X0"  );
        reader.search( "Ms. X15" );
        reader.search( "Ms. X24" );
        reader.search( "Ms. X50" );
    }
}