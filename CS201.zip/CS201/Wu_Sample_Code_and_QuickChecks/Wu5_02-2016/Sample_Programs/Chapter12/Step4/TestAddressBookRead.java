/*
    Introduction to OOP with Java (th Ed), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Test the read (and write) method (Step 3)

    File: Step3/TestAddressBookRead.java
*/

import java.io.*;

/**
 * This class is for testing the read operation of AddressBookStorage.
 */

class TestAddressBookRead {
  //--------------------------------
//    Data Members
//--------------------------------

    /**
     * An AddressBook object to be stored in a file
     */
    AddressBook         myBook;

    /**
     * A storage object that handles file i/o for AddressBook
     */
    AddressBookStorage  fileManager;

    //------------------------
    //  Main
    //-----------------------
    public static void main( String[] args )throws IOException {
        TestAddressBookWrite writer = new TestAddressBookWrite(15);
        TestAddressBookRead  reader = new TestAddressBookRead( );

        writer.write("book.data");
        reader.read("book.data");

        reader.search("Ms. X5");
    }


//-------------------------------------------------
//      Public Methods:
//
//          void    printout   (              )
//          void    testRead   (   String     )
//
//-------------------------------------------------

    /**
     * Prints out the data in the AddressBook loaded
     * from the file.
     *
     */
    public void search(String name) {
        Person person;

        person = myBook.search(name);

        if (person != null) {
           System.out.print(person.getName() + "   ");
           System.out.print(person.getAge()  + "   ");
           System.out.println(person.getGender() + "\n");
           
        } else {
           System.out.println("Error: object not found");
        }
    }


    /**
     * Read the address book to the specified file.
     *
     * @param filename the name of a file to load AddressBook
     *
     */
    public void read( String filename ) {
        fileManager = new AddressBookStorage(filename);

        try {
           myBook = fileManager.read();
        }
        catch (IOException e) {
           System.out.println("Error: IOException is thrown.");
        }
    }
}