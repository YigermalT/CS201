/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Display a Java source file.

    File: Ch12JavaViewer.java
    
    NOTE: This program is not mentioned in the textbook. 
*/

/*
    This program uses the JavaFilter class to restrict the listing
    to Java source files in JFileChooser. Inside the readSource method,
    the FileManager class is used to read the Java source file. 
    NOTE: Open only small files since the source code is display
    on the console which is not suitable for displaying a large
    amount of data.
*/

import javax.swing.*;
import java.io.*;

class Ch12JavaViewer {

	/** the content of file read */
	private String document;

//----------------------------------
//      Main method
//----------------------------------
    public static void main(String[] args) {
        Ch12JavaViewer viewer = new Ch12JavaViewer();
        viewer.start( );
    }

//----------------------------------
//    Constructors
//----------------------------------

    /**
     * Default constructor
     */
    public Ch12JavaViewer() {

    }


//-------------------------------------------------
//      Public Methods:
//
//
//------------------------------------------------

	/**
	 * The top-level method
	 *
	 */
	public void start( ) {

		if (openFile()) {
			//file is opened and document is read
			//correctly, so display it

			System.out.println(document);
		}
    }


//-------------------------------------------------
//      Private Methods:
//
//
//------------------------------------------------


    /**
     * Let the end user select the Java source file
     * to open.
     */
    private boolean openFile( ) {

        JFileChooser chooser;
        int          status;

        chooser = new JFileChooser( );

        //Use the following statement to open the file chooser
        //at the directory this class is being executed

        //chooser = new JFileChooser(System.getProperty("user.dir"));
        chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        chooser.setFileFilter(new JavaFilter());

        status = chooser.showOpenDialog(null);

        if (status == JFileChooser.APPROVE_OPTION) {
            document =  readSource(chooser.getSelectedFile());

            return true;

        } else {
            System.out.println("Open File dialog canceled");

            return false;
        }
    }

    /**
     * Opens the selected file and displays the file content
     *
     * @param file the file to open
     *
     * @exception IOException
     */
    private String readSource(File file) {

		String doc = "";

        try {
            FileManager fm = new FileManager();

            doc = fm.openFile(file.getAbsolutePath());

        } catch (IOException e) {
            System.out.println("Error in opening a file: \n"
                                            + e.getMessage());
        }

		return doc;
    }
}