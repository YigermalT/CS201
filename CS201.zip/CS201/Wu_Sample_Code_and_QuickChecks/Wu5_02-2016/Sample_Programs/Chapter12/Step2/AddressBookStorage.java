/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: The class that provides the
                                file I/O for AddressBook (Step 2)

    File: Step2/AddressBookStorage.java

    (Step 2 implements the write method)
*/

import java.io.*;

/**
 * This class provides a file i/o capability to save
 * and load the AddressBook object.
 *
 */
class AddressBookStorage {

//--------------------------------
//    Data Members
//--------------------------------

    /**
     * The name of the file where an AddressBook is stored
     */
   private String filename;

//--------------------------------
//    Constructors
//--------------------------------

    /**
     * Default constructor.
     */
   public AddressBookStorage (String filename) {
      setFile(filename);
   }

//-------------------------------------------------
//      Public Methods:
//
//          void    setFile    (   String     )
//          void    write      ( AddressBook  )
//------------------------------------------------


   /**
    * Writes the address book to the designated file
    *
    * @param book the AddressBook to save to a file
    *
    */
   public void write(AddressBook book) throws IOException {

      //first create an ObjectOutputStream
      File outFile = new File(filename);
      FileOutputStream outFileStream =
               new FileOutputStream(outFile);
      ObjectOutputStream outObjectStream =
               new ObjectOutputStream(outFileStream);

      //save the data to it
      outObjectStream.writeObject(book);

      //and close it
      outObjectStream.close();
   }



    /**
     * Sets the filename to the passed string.
     *
     * @param filename the name of the file to store
     *        an AddressBook object
     */
   public void setFile(String filename) {

      this.filename = filename;
     // System.out.println("Inside setFile. Filename is " + filename); //TEMP
   }

}