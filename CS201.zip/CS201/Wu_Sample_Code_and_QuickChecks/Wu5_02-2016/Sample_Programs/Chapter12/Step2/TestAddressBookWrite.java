/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Test the write method (Step 2)

    File: Setp2/TestAddressBookWrite.java
*/

import java.io.*;

/**
 * This class is for testing the write operation of AddressBookStorage.
 *
 */

class TestAddressBookWrite {

//--------------------------------
//    Data Members
//--------------------------------

    /**
     * An AddressBook object to be stored in a file
     */
    AddressBook         myBook;

    /**
     * A storage object that handles file i/o for AddressBook
     */
    AddressBookStorage  fileManager;


//-------------------------------
//  Main
//-------------------------------
public static void main(String[] args)throws IOException {
    TestAddressBookWrite  tester = new TestAddressBookWrite(15);

    tester.write("book.data");
}


//--------------------------------
//    Constructors
//--------------------------------

    /**
     * Default constructor.
     * Creates a dummy address book of size N.
     */
    public TestAddressBookWrite( int N ) {
        myBook = new AddressBookVer1(N);

        for (int i = 0; i < N; i++) {
           Person person = new Person("Ms. X" + i, 10, 'F');
           myBook.add(person);
        }
    }

//-------------------------------------------------
//      Public Methods:
//
//          void    write   (   String     )
//
//-------------------------------------------------

    /**
     * Writes the address book to the specified file.
     *
     * @param filename the name of a file to store AddressBook
     *
     */
    public void write(String filename) {
         fileManager = new AddressBookStorage(filename);

         try {
            fileManager.write(myBook);
         }
         catch (IOException e) {
            System.out.println("Error: IOException is thrown.");
         }
    }
}