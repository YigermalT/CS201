/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 12 Sample Program: Driver class to test
                               the skeleton AddressBookStorage (Step 1)

    File: Step1/TestAddressBookStorage.java 
*/

class TestAddressBookStorage {

   public static void main (String[] args) {

      AddressBookStorage fileManager;

      fileManager = new AddressBookStorage("one.data");
      fileManager.setFile("two.data");
      fileManager.setFile("three.data");
   }
}