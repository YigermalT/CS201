/*
    Introduction to OOP with Java (Comprehensive Version 1st Ed), McGraw-Hill

    Wu/Otani

    Chapter 2 Sample Program: Displays the Monogram

    File: Step1/Ch2Monogram.java

*/

import java.util.*;

class Ch2Monogram {

    public static void main( String[] args ) {
    	
    	String name;

        Scanner scanner = new Scanner(System.in);

        scanner.useDelimiter(System.getProperty("line.separator"));
        
        System.out.print("Enter your full name (first, middle, last):");
        
        name = scanner.next( );

        System.out.println("Name entered: " + name);
    }
}