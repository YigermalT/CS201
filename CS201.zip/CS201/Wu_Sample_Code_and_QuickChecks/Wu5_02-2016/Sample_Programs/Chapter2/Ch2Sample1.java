/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 2 Sample Program: Displays a Window

    File: Ch2Sample1.java

*/

import javax.swing.*;

class Ch2Sample1 {

    public static void main(String[] args) {

        JFrame myWindow;

        myWindow = new JFrame();

        myWindow.setSize(300, 200);
        myWindow.setTitle("My First Java Program");
        myWindow.setVisible(true);

        /* The following statement terminates the program
         * automatically when the frame window is closed. This way
         * you don't have to terminate the program explicitly
         * from your Java IDE after closing the window.
         */
        myWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
}