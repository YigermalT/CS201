/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 13 Sample Program

    File: Dog.java

*/

class Dog extends Pet {

    public String fetch( ) {
        return "Yes, master. Fetch I will.";
    }

}
