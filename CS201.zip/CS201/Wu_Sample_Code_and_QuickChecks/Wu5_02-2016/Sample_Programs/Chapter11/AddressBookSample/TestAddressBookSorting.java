package AddressBookSample;
/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 11 Sample Program: Addressbook Interface

    Test program to verify the new AddressBook and Person classes

    File: AddressBookSample/TestAddressBookSorting.java
*/

import java.util.*;

class TestAddressBookSorting {

    public static void main(String[] args) {

        TestAddressBookSorting tester = new TestAddressBookSorting();
        tester.start();
    }

    private void start( ) {
        
        String[] names = {"ape", "cat", "bee", "bat", "eel",
                          "dog", "gnu", "yak", "fox", "cow",
                          "hen", "tic", "man"};
        
        Scanner scanner = new Scanner(System.in);
        
        AddressBook ab;

        System.out.print("Version #:");
        
        int version = scanner.nextInt();

        switch (version) {
            case 1:  ab = new AddressBookVer1(); break;
            case 2:  ab = new AddressBookVer2(); break;
            case 3:  ab = new AddressBookVer3(); break;
            default: ab = new AddressBookVer1(); break;
        }

        for (String aName : names) {

            Person p = new Person(aName, random(10, 50), random(0,1)==0?'M':'F'); 
                                               //if(random(0,1) ==0) 'M' else 'F'
            ab.add(p);
        }


        Person[] sortedlist;
        
        sortedlist = ab.sort(Person.AGE);  //sort by age

        for (Person p : sortedlist) {
            System.out.println(p.toString( ));
        }

        System.out.println(" ");

        sortedlist = ab.sort(Person.NAME); //sort by name

        for (Person p : sortedlist) {
            System.out.println(p.toString( ));
        }
    }

    /**
     * Returns a random integer between low
     * and high, inclusive.
     *
     * @param low  the low bound of the random number
     * @param high the high bound of the random number
     *
     * @return a random integer between low and high
     */
    private int random(int low, int high) {

        return (int) Math.floor(Math.random() * (high - low + 1))
                      + low;
    }

}