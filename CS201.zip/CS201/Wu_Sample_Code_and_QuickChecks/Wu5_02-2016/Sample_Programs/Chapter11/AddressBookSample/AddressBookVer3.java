package AddressBookSample;
/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 11 Sample Program: Version 3 implementation of
                                Addressbook Interface.
                                This version uses HashMap
                                for data management.

    Inner classes AgeComparator and NameComparator are defined.

    File: AddressBookSample/AddressBookVer3.java
*/

import java.util.*;

/**
 * This class is designed to manage an address book that contains
 * Person objects. The user can specify the size of the address book
 * when it is created. If no size is specified, then the default size
 * is set to 25 Person objects.
 *
 * <p>
 * This class uses the java.util.HashMap for data management.
 *
 */
class AddressBookVer3 implements AddressBook {

//--------------------------------
//    Data Members
//--------------------------------
    /**
     * Default size of the array
     */
    private static final int  DEFAULT_SIZE = 25;

    /**
     * The array of Person objects
     */
    private Map<String,Person>   entry;


//--------------------------------
//    Constructors
//--------------------------------

    /**
     * Default constructor.
     * Creates an address book of size 25.
     */
    public AddressBookVer3( ) {
        this(DEFAULT_SIZE);
    }


    /**
     * Creates an address book with the designated size.
     *
     * @param size the size of this address book.
     */
    public AddressBookVer3(int size) {
        entry = new HashMap<String,Person>(size);

 //       System.out.println("array of "+ size + " is created."); //TEMP
    }


//-------------------------------------------------
//      Public Methods:
//
//          void      add       (   Person     )
//          void      delete    (   String     )
//          Person    search    (   String     )
//          Person[ ] sort      (   int        )
//
//------------------------------------------------

    /**
     * Adds a new Person to this address book.
     *
     * @param newPerson a new Person object to add
     */
    public void add(Person newPerson) {
        entry.put(newPerson.getName(), newPerson);
    }

    /**
     * Deletes the Person whose name is 'searchName'.
     *
     * @param searchName the name of a Person to delete
     *
     * @return true if removed successfully; false otherwise
     */
    public boolean delete(String searchName) {

        boolean status;
        
        Person  p = entry.remove(searchName);

        if (p == null) {
            status = false;
        } else {
            status = true;
        }

        return status;
    }

    /**
     * Searches this address book for a Person
     * whose name is <code>searchName</code>.
     *
     * @param searchName the name to search
     *
     * @return a Person object if found; otherwise null
     */
    public Person search(String searchName) {

        return entry.get(searchName);
    }


    /**
     * Sorts the address book using 'attribute'
     * as the criteria for sorting.
     *
     * @param attribute the attribute of Person used for sorting
     *
     * @return a sorted list of Person
     */
    public Person[ ] sort(int attribute) {

        if (!(attribute == Person.NAME || attribute == Person.AGE) ) {
            throw new IllegalArgumentException( );
        }

        Person[ ] sortedList = new Person[entry.size()];
        
        entry.values().toArray(sortedList);

        Arrays.sort(sortedList, getComparator(attribute));

        return sortedList;
    }


//-------------------------------------------------
//      Private Methods:
//
//          Comparator  getComparator   ( int       )
//
//------------------------------------------------

    /**
     * Gets a corresponding comparator for a given
     *
     */
    private Comparator<Person> getComparator(int attribute) {
        Comparator<Person> comp = null;

        if (attribute == Person.AGE) {
            comp = new AgeComparator( );

        } else {
            assert attribute == Person.NAME:
                    "Attribute not recognized for sorting";

            comp = new NameComparator( );
        }

        return comp;
    }


//-------------------------------------------------
//
//      Inner Classes
//
//------------------------------------------------

    //Inner class for comparing age
    class AgeComparator implements Comparator<Person> {

        private final int LESS = -1;
        private final int EQUAL = 0;
        private final int MORE  = 1;

        public int compare(Person p1, Person p2) {
            int comparisonResult;

            int p1age = p1.getAge( );
            int p2age = p2.getAge( );

            if (p1age < p2age) {
                comparisonResult = LESS;
            } else if (p1age == p2age) {
                comparisonResult = EQUAL;
            } else {
                assert p1age > p2age;
                comparisonResult = MORE;
            }

            return comparisonResult;
        }
    }

    //Inner class for comparing name
    class NameComparator implements Comparator<Person> {

        public int compare(Person p1, Person p2) {

            String p1name = p1.getName( );
            String p2name = p2.getName( );

            return p1name.compareTo(p2name);
        }
    }

/*
    class GenAgeComparator implements Comparator<Person> {

        private final int LESS = -1;
        private final int EQUAL = 0;
        private final int MORE  = 1;

        public int compare(Person p1, Person p2) {
            int comparisonResult;

            int p1age = p1.getAge( );
            int p2age = p2.getAge( );

            char p1gender = p1.getGender();
            char p2gender = p2.getGender();

            if (p1gender < p2gender) {
                comparisonResult = LESS;
            } else if (p1gender == p2gender) {
                if (p2age < p1age) {
                    comparisonResult = LESS;
                } else if (p2age == p1age) {
                    comparisonResult = EQUAL;
                } else {
                    assert p2age > p1age;
                    comparisonResult = MORE;
                }
            } else {
                assert p1gender > p2gender;
                comparisonResult = MORE;
            }

            return comparisonResult;
        }
    }
*/

}