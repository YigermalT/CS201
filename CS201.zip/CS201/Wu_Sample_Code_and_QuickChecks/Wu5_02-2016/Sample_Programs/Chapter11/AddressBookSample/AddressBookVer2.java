package AddressBookSample;
/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 11 Sample Program: Version 2 implementation of
                                Addressbook Interface.
                                This version uses the Arrays
                                class for sorting.

    Inner classes AgeComparator and NameComparator are defined.

    File: AddressBookSample/ddressBookVer2.java
*/

import java.util.*;

/**
 * This class is designed to manage an address book that contains
 * Person objects. The user can specify the size of the address book
 * when it is created. If no size is specified, then the default size
 * is set to 25 Person objects.
 *
 */
class AddressBookVer2 implements AddressBook {

//--------------------------------
//    Data Members
//--------------------------------

    /**
     * Default size of the array
     */
    private static final int  DEFAULT_SIZE = 25;

    /**
     * Constant for signaling an unsuccessful search
     */
    private static final int  NOT_FOUND    = -1;

    /**
     * The array of Person objects
     */
    private Person[]   entry;

    /**
     * The number of elements in the <code>entry</code> array,
     * which is also the position to add the next Person object
     */
    private int        count;

//--------------------------------
//    Constructors
//--------------------------------

    /**
     * Default constructor.
     * Creates an address book of size 25.
     */
    public AddressBookVer2( ) {
        this( DEFAULT_SIZE );
    }


    /**
     * Creates an address book with the designated size.
     *
     * @param size the size of this address book.
     */
    public AddressBookVer2(int size) {
        count = 0;

        if (size <= 0) { //invalid data value, use default
            throw new IllegalArgumentException("Size must be positive");
        }

        entry = new Person[size];

 //       System.out.println("array of "+ size + " is created."); //TEMP
    }


//-------------------------------------------------
//      Public Methods:
//
//          void      add       (   Person     )
//          void      delete    (   String     )
//          Person    search    (   String     )
//          Person[ ] sort      (   int        )
//
//------------------------------------------------

    /**
     * Adds a new Person to this address book.
     * If the overflow occurs, the array size
     * is increased by 50 percent.
     *
     * @param newPerson a new Person object to add
     */
    public void add(Person newPerson) {
        if (count == entry.length) {   //no more space left,
            expand( );                //create a new larger array
        }

        //at this point, entry refers to a new larger array
        entry[count] = newPerson;
        count++;
    }

    /**
     * Deletes the Person whose name is 'searchName'.
     *
     * @param searchName the name of a Person to delete
     *
     * @return true if removed successfully; false otherwise
     */
    public boolean delete(String searchName) {
        boolean    status;
        int        loc;

        loc = findIndex(searchName);

        if (loc == NOT_FOUND) {
            status = false;

        } else { //found, pack the hole

            entry[loc] = entry[count-1];

            status = true;
            count--;        //decrement count,
                            //since we now have one less element
        }

        return status;
    }

    /**
     * Searches this address book for a Person
     * whose name is <code>searchName</code>.
     *
     * @param searchName the name to search
     *
     * @return a Person object if found; otherwise null
     */
    public Person search(String searchName) {
        Person foundPerson;
        int    loc = 0;

        while (loc < count &&
                !searchName.equals(entry[loc].getName())) {
            loc++;
        }

        if (loc == count) {
            foundPerson = null;

        } else {
            foundPerson = entry[loc];
        }

        return foundPerson;
    }


    /**
     * Sorts the address book using 'attribute'
     * as the criteria for sorting.
     *
     * @param attribute the attribute of Person used for sorting
     *
     * @return a sorted list of Person
     */
    public Person[ ] sort (int attribute) {

        if (!(attribute == Person.NAME || attribute == Person.AGE)) {
            throw new IllegalArgumentException( );
        }

        Person[ ] sortedList = new Person[ count ];

        //copy references to sortedList
        for (int i = 0; i < count; i++) {
            sortedList[i] = entry[i];
        }

        Arrays.sort(sortedList, getComparator(attribute));

        return sortedList;
    }


//-------------------------------------------------
//      Private Methods:
//
//          void        expand          (           )
//          int         findIndex       ( String    )
//          Comparator  getComparator   ( int       )
//
//------------------------------------------------

    /**
     * Enlarges the size of <code>entry</code> array to
     * eliminate the overflow condition. The new array
     * is 50 percent larger than the current array.
     */
    private void expand( ) {
        //create a new array whose size is 150% of
        //the current array
        int newLength = (int) (1.5 * entry.length);
        Person[] temp = new Person[newLength];

        //now copy the data to the new array
        for (int i = 0; i < entry.length; i++) {
            temp[i] = entry[i];
        }

        //finally set the variable entry to point to the new array
        entry = temp;

   //     System.out.println("Inside the method enlarge");            //TEMP
   //     System.out.println("Size of a new array: " + entry.length); //TEMP
    }

    /**
     * Finds the index in the array where <code>searchName</code>
     * is the name of a person to locate.
     *
     * @param searchName the name of person to find
     *
     * @return the index of the found Person in the array; NOT_FOUND
     *         if the searched person is not found
     */
    private int findIndex(String searchName) {
        int loc = 0;

        while (loc < count &&
                !searchName.equals( entry[loc].getName())) {
            loc++;
        }

        if (loc == count) {

            loc = NOT_FOUND;
        }

        return loc;
    }


    /**
     * Gets a corresponding comparator for a given
     *
     */
    private Comparator<Person> getComparator(int attribute) {
        
        Comparator<Person> comp = null;

        if (attribute == Person.AGE) {
            comp = new AgeComparator( );

        } else {
            assert attribute == Person.NAME:
                    "Attribute not recognized for sorting";

            comp = new NameComparator( );
        }

        return comp;
    }


//-------------------------------------------------
//
//      Inner Classes
//
//------------------------------------------------

    //Inner class for comparing age
    class AgeComparator implements Comparator<Person> {

        private final int LESS = -1;
        private final int EQUAL = 0;
        private final int MORE  = 1;

        public int compare(Person p1, Person p2) {
            int comparisonResult;

            int p1age = p1.getAge( );
            int p2age = p2.getAge( );

            if (p1age < p2age) {
                comparisonResult = LESS;
            } else if (p1age == p2age) {
                comparisonResult = EQUAL;
            } else {
                assert p1age > p2age;
                comparisonResult = MORE;
            }

            return comparisonResult;
        }
    }

    //Inner class for comparing name
    class NameComparator implements Comparator<Person> {

        public int compare(Person p1, Person p2) {

            String p1name = p1.getName( );
            String p2name = p2.getName( );

            return p1name.compareTo(p2name);

        }
    }

/*
    class GenAgeComparator implements Comparator<Person> {

        private final int LESS = -1;
        private final int EQUAL = 0;
        private final int MORE  = 1;

        public int compare(Person p1, Person p2) {
            int comparisonResult;

            int p1age = p1.getAge( );
            int p2age = p2.getAge( );

            char p1gender = p1.getGender();
            char p2gender = p2.getGender();

            if (p1gender < p2gender) {
                comparisonResult = LESS;
            } else if (p1gender == p2gender) {
                if (p2age < p1age) {
                    comparisonResult = LESS;
                } else if (p2age == p1age) {
                    comparisonResult = EQUAL;
                } else {
                    assert p2age > p1age;
                    comparisonResult = MORE;
                }
            } else {
                assert p1gender > p2gender;
                comparisonResult = MORE;
            }

            return comparisonResult;
        }
    }
*/
}