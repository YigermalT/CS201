/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 11 Sample Program: Test bubble sort.

    File: Ch11TestBubbleSort.java
*/

class Ch11TestBubbleSort {

    public static void main (String[] args) {

        int[ ] number = new int[50];

        SortingRoutines sorter = new SortingRoutines( );

        //Store random numbers between 0 and 9999
        //into an array of int.
        //Duplicate values in the array are okay

        for (int i = 0; i < number.length; i++ ) {

            number[ i ] = (int) Math.floor( Math.random() * 10000 );
        }

        System.out.println(" Unsorted List ");
        System.out.println("");

        for (int i = 0; i < number.length; i++ ) {

            System.out.println( number[ i ] );
        }

        //Sort
        sorter.bubbleSort( number );

        //Display the array elments after sorting
        System.out.println("\n\n");
        System.out.println(" Sorted List ");
        System.out.println("");

        for (int i = 0; i < number.length; i++ ) {

            System.out.println(number[i]);
        }
    }
}