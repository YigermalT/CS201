/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 11 Sample Program: Test heapsort.

    File: Ch11TestHeapsort.java
*/

class Ch11TestHeapsort {

    public static void main (String[] args) {

       // int[ ] number = {90, 84, 44, 77, 12, 5, 38, 17, 23 } ;

                        //{90, 38, 44, 84, 5, 23, 17, 77, 12 } ;

        int[ ] number = new int[50];
        int[ ] sortedList;

        //Store random numbers between 0 and 9999
        //into an array of int.
        //Duplicate values in the array are okay
        for (int i = 0; i < number.length; i++ ) {

            number[ i ] = (int) Math.floor( Math.random() * 10000 );
        }

        //Display the array elments before sorting
        System.out.println(" Unsorted List ");
        System.out.println("");

        for (int i = 0; i < number.length; i++ ) {

            System.out.println(number[i]);
        }

        Heap heap = new Heap( );

        heap.setData(number);

        sortedList = heap.sort( );

        System.out.println("\n\n");
        System.out.println(" Sorted List ");
        System.out.println("");

        for (int i = 0; i < sortedList.length; i++ ) { //print out
            System.out.println("   " + sortedList[i]);                                                  //the sorted
        }
    }
}