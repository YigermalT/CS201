/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 11 Sample Program: Test selection sort.

    File: Ch11TestSelectionSort.java
*/

class Ch11TestSelectionSort {

    public static void main (String[] args) {

        int[ ] number = new int[50];

        SortingRoutines sorter = new SortingRoutines( );

        //Store random numbers between 0 and 9999
        //into an array of int.
        //Duplicate values in the array are okay

        for (int i = 0; i < number.length; i++ ) {

            number[ i ] = (int) Math.floor( Math.random() * 10000 );
        }

        //Display the array elments before sorting
        System.out.println(" Unsorted List ");
        System.out.println("");

        for (int i = 0; i < number.length; i++ ) {

            System.out.println( number[ i ] );
        }

        //Sort
        sorter.selectionSort( number );


        //Display the array elments after sorting
        System.out.println("\n\n");
        System.out.println(" Sorted List ");
        System.out.println("");

        for (int i = 0; i < number.length; i++ ) {

            System.out.println(number[i]);
        }
    }
}