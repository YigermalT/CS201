/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 3 Sample Program: Compute Area and Circumference
                              with formatting

    File: Ch2Circle2.java

*/

import java.text.*;

class Ch3Circle2 {

    public static void main( String[] args ) {

        final double PI = 3.14159;

        double radius, area, circumference;

        DecimalFormat df = new DecimalFormat("0.000");

        radius = 2.35;;

        //compute the area and circumference
        area          = PI * radius * radius;
        circumference = 2.0 * PI * radius;

        
        System.out.println("Given Radius: " + df.format(radius));
        System.out.println("Area: " + df.format(area));
        System.out.println("Circumference: " + df.format(circumference));
    }
}