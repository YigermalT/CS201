/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    File: Step5/Ch5DrawShape.java

*/
import java.awt.*;
import java.util.*;

//Start drawing shapes (Step5)

class Ch5DrawShape {

    // The DrawingBoard object for simulating screensaver 
    private DrawingBoard canvas;
    
    //Scanner for getting input from System.in
    private Scanner scanner;

    
 //---------------------------
 //  Main method
 //---------------------------

    public static void main( String[] args ) {

        Ch5DrawShape screensaver = new Ch5DrawShape( );

        screensaver.start();
    }

//------------------------------
//
//  Constructor
//
//------------------------------
    
    public Ch5DrawShape( ) {

        canvas = new DrawingBoard( );
        
        scanner = new Scanner(System.in);
    }


//-----------------------------------
//
//  Public Methods:
//
//      void    start   (   )
//
//-------------------------------------

    // The top method to start the whole program
    public void start( ) {

        DrawableShape shape1 = getShape();

        canvas.addShape(shape1);

        canvas.setMovement(inputMotionType());

        canvas.setVisible(true);
        canvas.start();

    }


//-----------------------------------
//
//  Private Methods:
//
//      DrawableShape    getShape        (       )
//      Point            inputCenterPoint(       )
//      Dimension        inputDimension  (       )
//      int              inputShapeType  (       )
//
//-------------------------------------
    /*
      Gets the shape selection from the user. The possible
      shapes are Ellipse, Triangle, and Rectangle. The size
      of the selected shape is expressed in terms of its width
      and height, as the shape's bounding rectangle. The user
      has an option of specifying the center point. A random
      point is chosen if the user does not specify the
      center point.
    */
    private DrawableShape getShape( ) {

        DrawableShape.Type type = inputShapeType();

        Dimension dim = inputDimension();

        Point centerPt = inputCenterPoint();

        Color color = inputColor();

        DrawableShape shape = new DrawableShape(type, dim, centerPt, color);

        return shape;
    }

    // Let the user select the center point of the shape.
    private Point inputCenterPoint( ) {

        System.out.print("Enter the x value of the center point\n" +
                         "between 200 and 800 inclusive: ");

        int x = scanner.nextInt();

        if (x < 200 || x > 800) {
            x = 200;
        }

        System.out.print("Enter the y value of the center point\n" +
                         "between 100 and 500 inclusive: ");

        int y = scanner.nextInt();

        if (y < 100 || y > 500) {
            y = 100;
        }

        return new Point(x, y);
    }  
    
    
    //  Let the user select a color.
    private Color inputColor( ) {

        System.out.print("Selection: Enter the Color number\n" +
                            "   1 - Red \n" +
                            "   2 - Green \n" +
                            "   3 - Blue \n" +
                            "   4 - Yellow \n" +
                            "   5 - Magenta \n" );

        int selection = scanner.nextInt();

        Color color;
        
        switch (selection) {

            case 1:  color = Color.RED;
                     break;

            case 2:  color = Color.GREEN;
                     break;

            case 3:  color = Color.BLUE;
                     break;

            case 4:  color = Color.YELLOW;
                     break;

            case 5:  color = Color.MAGENTA;
                     break;

            default: color = Color.RED;
                     break;
        }

        return color;
    } 
    
    
    // Let the user select the dimension of the shape.
    private Dimension inputDimension( ) {

        System.out.print("Enter the width of the shape\n" +
                         "between 100 and 500 inclusive: ");

        int width = scanner.nextInt();

        if (width < 100 || width > 500) {
            width = 100;
        }

        System.out.print("Enter the height of the shape\n" +
                          "between 100 and 500 inclusive: ");

        int height = scanner.nextInt();

        if (height < 100 || height > 500) {
            height = 100;
        }

        return new Dimension(width, height);
    }

    //Input the movement type
    private DrawingBoard.Movement inputMotionType() {
        
        System.out.print("Selection: Enter the Motion number\n" +
                "   1 - Stationary (no movement) \n" +
                "   2 - Random Movement \n" +
                "   3 - Smooth Movement \n" );

        int selection = scanner.nextInt();
        
        DrawingBoard.Movement type;
        
        switch (selection) {
        
           case 1:  type = DrawingBoard.Movement.STATIONARY;
                    break;
        
           case 2:  type = DrawingBoard.Movement.RANDOM;
                    break;
        
           case 3:  type = DrawingBoard.Movement.SMOOTH;
                    break;
        
           default: type = DrawingBoard.Movement.SMOOTH;
                    break;
        }
        
        return type;
                
    }

    // Let the user select the shape: Ellipse, Triangle, and
    // Rectangle.
    private DrawableShape.Type inputShapeType( ) {

        System.out.print("Selection: Enter the Shape number\n" +
                         "   1 - Ellipse \n" +
                         "   2 - Rectangle \n" +
                         "   3 - Rounded Rectangle \n" );

        int selection = scanner.nextInt();

        DrawableShape.Type type;
        
        switch (selection) {

            case 1:  type = DrawableShape.Type.ELLIPSE;
                     break;

            case 2:  type = DrawableShape.Type.RECTANGLE;
                     break;

            case 3:  type = DrawableShape.Type.ROUNDED_RECTANGLE;
                     break;

            default: type = DrawableShape.Type.ELLIPSE;
                     break;
        }

        return type;
    }
}