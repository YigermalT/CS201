/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    File: RoomWinner.java

*/
import java.awt.*;
import javax.swing.*;

class Ch5RoomWinner {
    
    
    public static void main( String[] args ) {
        
        JFrame    win;
        Container contentPane;
        Graphics  g;
        
        GraphicLotteryCard one, two, three;
        
        win = new JFrame("Room Winner");
        win.setSize(300, 200);
        win.setLocation(100,100);
        win.setVisible(true);
        
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //see Hints, Tips, & Pitfalls box at beginning of Chapter 2

        contentPane = win.getContentPane();
        contentPane.setBackground(Color.WHITE);

        g = contentPane.getGraphics();
        
        one   = new GraphicLotteryCard( );
        two   = new GraphicLotteryCard( );
        three = new GraphicLotteryCard( );
        
        one.spin();
        two.spin();
        three.spin();
        
//      NOTE:
//      Depending on the speed of your PC, you may
//      have to include the following 'try' statement
//      to put a delay before
//      drawing the rectangle. 1000 == 1 second,
//      so 200 means 0.2 seconds delay.
//
//      If you do not see a rectangle drawn in the window,
//      include the following 'try' statement. Experiment
//      by increasing and decreasing the value of 200
//      and see the effect.

        try {Thread.sleep(200);} catch (Exception e) {}
        
          one.draw(g, 10, 20);
          two.draw(g, 50, 20);
        three.draw(g, 90, 20);
        
        //NOTE:
        //      The following is a more generalized version
        //      of the above. 
        /*
        int cardWidth = GraphicLotteryCard.WIDTH;
          one.draw(g, 10, 20);
          two.draw(g, 10 + cardWidth + 5, 20);
        three.draw(g, 10 + 2*(cardWidth+ 5), 20);
        */
    }
}