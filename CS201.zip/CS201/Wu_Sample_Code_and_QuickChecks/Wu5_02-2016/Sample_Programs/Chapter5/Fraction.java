/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 5 The Fraction class

    File: Fraction.java

*/

/*
    This is an INCOMPLETE class. The full version is completed
    in Chapter 7.
    
    The version shown here only illustrates the use of equals method.
    It doesn't include methods for arithmetic
    operations, such as addition and subtraction, and other necessary
    methods.
 
*/
public class Fraction {

    /// the numerator of this fraction 
	private int numerator;

    // the denominator of this fraction 
	private int denominator;
 
//--------------------------------------
//  Constructor
//--------------------------------------   
    
    // Creates a fraction 0/1
    public Fraction( ) {
        numerator = 0;
        denominator = 1;
    }
    

//---------------------------------------------------------
//  Public Methods
//
//      boolean     equals          (   Fraction    )
// 
//      int         getDenominator  (               )
//      int         getNumerator    (               )
//
//      void        setDenominator  (   int         )
//      void        setNumerator    (   int         )
//
//      String      toString        (               )
//
//---------------------------------------------------------

       
    /*
      Compares this fraction and the parameter frac for
      equality. This method compares the two by first
      reducing them to the simplest form.
    */
	public boolean equals(Fraction number) {
        
        return (numerator == number.getNumerator()
                && denominator == number.getDenominator());
	}
 
    /*
      Returns the denominator of this fraction
    */
	public int getDenominator( ) {
		return denominator;
	}  
    
    
    /*
      Returns the numerator of this fraction
    */
	public int getNumerator( ) {
		return numerator;
	}
    
    /*
      Sets the denominator of this fraction
    */
	public void setDenominator(int denom) {
        denominator = denom;
    }
    
    /*
      Sets the numerator of this fraction
    */
	public void setNumerator(int num) {
        numerator = num;
    }  
    
    /*
      Returns the String representation of this Fraction
    */
    public String toString( ) {
        
        return getNumerator() + "/" + getDenominator();
    }
    
    //Sample main to illustrate how two Fraction objects are
    //compared
    public static void main(String[] args) {
    	
    	Fraction f1, f2;
    	f1 = new Fraction( );
    	f1.setNumerator(1);
    	f1.setDenominator(3);
    	
    	f2 = f1; //Fraction 1/3 now has two names: f1 and f2
    	
    	if (f1 == f2) {
    		System.out.println("f1 and f2 point to the same object");
    	} else {
    		System.out.println("f1 and f2 point to different objects");
    	}
    	
    	f2 = new Fraction();
    	f2.setNumerator(1);
    	f2.setDenominator(3);
    	
    	if (f1.equals(f2)) {
    		System.out.println("f1 and f2 have the same values");
    	} else {
    		System.out.println("f1 and f2 have different values");
    	}
		
	}
}

