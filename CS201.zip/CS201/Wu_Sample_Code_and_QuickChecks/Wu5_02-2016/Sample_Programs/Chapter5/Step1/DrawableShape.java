/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 5 The DrawableShape class

    File: Step1/DrawableShape.java

*/

import java.awt.*;


class DrawableShape {

//----------------------------------
//    Constructors
//----------------------------------

    // Default constructor
    public DrawableShape( ) {

    }


//-------------------------------------------------
//      Public Methods:
//
//          void      draw            ( java.awt.Graphcs  )
//
//          Point     getCenterPoint  (                   )
//          Dimension getDimension    (                   )
//
//          void      setCenterPoint  ( java.awt.Point    )
//
//------------------------------------------------

    // Draws this object on the passed Graphics context
    public void draw(Graphics g) {


    }


    // Returns the center point of this drawable shape.
    public Point getCenterPoint( ) {

        return null;
    }


    // Returns the dimension of this shape.
    public Dimension getDimension( ) {

       return null;
    }


    // Sets the center point of this drawable shape.
    public void setCenterPoint(Point point) {

    }

}