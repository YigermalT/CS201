/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani
    
    Chapter 5 Sample Development: Drawing Shapes (Step 1)

    File: Step1/Ch5DrawShape.java
 
 */

class Ch5DrawShape {

    // The DrawingBoard object for simulating screensaver 
    private DrawingBoard canvas;

    public Ch5DrawShape( ) {

        canvas = new DrawingBoard( );
    }

    public static void main( String[] args ) {

        Ch5DrawShape screensaver = new Ch5DrawShape( );

        screensaver.start();
    }

    public void start( ) {

        canvas.setVisible(true);
    }
}