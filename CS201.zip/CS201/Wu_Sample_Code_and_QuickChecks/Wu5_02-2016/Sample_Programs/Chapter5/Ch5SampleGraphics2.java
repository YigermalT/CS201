/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 5 Sample Program: Draw one blue square and
                              one filled red square on light gray
                              background content pane

    File: Ch5SampleGraphics2.java

*/

import javax.swing.*; //for JFrame
import java.awt.*; //for Graphics and Container

class Ch5SampleGraphics2 {

    public static void main( String[] args ) {

        JFrame    win;
        Container contentPane;
        Graphics  g;

        win = new JFrame("Rectangles");
        win.setSize(300, 200);
        win.setLocation(100,100);
        win.setVisible(true);

        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
       //see Hints, Tips, & Pitfalls box at beginning of Chapter 2
        
        contentPane = win.getContentPane();
        contentPane.setBackground(Color.LIGHT_GRAY);

        //NOTE: 
        //      Depending on the speed of your PC, you may
        //      have to include the following 'try' statement 
        //      to put a delay before
        //      drawing the rectangle. 1000 == 1 second,
        //      so 200 means 0.2 seconds delay.
        //
        //      If you do not see a rectangle drawn in the window,
        //      include the following 'try' statement. Experiment
        //      by increasing and decreasing the value of 200
        //      and see the effect. 
        //   
        try {Thread.sleep(200);} catch (Exception e) {}
    
        g = contentPane.getGraphics();
        g.setColor(Color.blue);
        g.drawRect(50,50,100,30);

        g.setColor(Color.red);
        g.fillRect(175,50,100,30);

    }
}