/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    File: Step2/Ch5DrawShape.java

*/
import java.awt.*;

//Instantiable Main Class
class Ch5DrawShape {

    // The DrawingBoard object for simulating screensaver 
    private DrawingBoard canvas;

    public Ch5DrawShape( ) {

        canvas = new DrawingBoard( );
    }

 //---------------------------
 //  Main method
 //---------------------------

    public static void main( String[] args ) {

        Ch5DrawShape screensaver = new Ch5DrawShape( );

        screensaver.start();
    }

    public void start( ) {

        DrawableShape shape1 = new DrawableShape();
        DrawableShape shape2 = new DrawableShape();
        DrawableShape shape3 = new DrawableShape();

        shape1.setCenterPoint(new Point(250,300));
        shape2.setCenterPoint(new Point(500,300));
        shape3.setCenterPoint(new Point(750,300));

        canvas.addShape(shape1);
        canvas.addShape(shape2);
        canvas.addShape(shape3);

        canvas.setMovement(DrawingBoard.Movement.SMOOTH);

        //Try other options and verify the effect

  //      canvas.setMovement(DrawingBoard.STATIONARY);
  //      canvas.setMovement(DrawingBoard.RANDOM);
  //      canvas.setDelayTime(0.1);
  //      canvas.setBackground(Color.white);

        canvas.setVisible(true); //this is really not necessary
                                //because the canvas.start will
                                //call setVisible if the window
                                //yet visible.
        canvas.start();

    }

}