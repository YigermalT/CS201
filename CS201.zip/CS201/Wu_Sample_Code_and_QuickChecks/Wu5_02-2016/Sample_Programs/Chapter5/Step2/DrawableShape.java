/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 5 The DrawableShape class

    File: Step2/DrawableShape.java

*/

import java.awt.*;

//Step 2: Add a preliminary DrawableShape class

class DrawableShape {

//----------------------------------
//    Data Members
//----------------------------------

    private Point   centerPoint;


//----------------------------------
//    Constructors
//----------------------------------

    // Default constructor
    public DrawableShape( ) {

       centerPoint = null;

    }


//-------------------------------------------------
//      Public Methods:
//
//          void      draw            ( java.awt.Graphcs  )
//
//          Point     getCenterPoint  (                   )
//          Dimension getDimension    (                   )
//
//          void      setCenterPoint  ( java.awt.Point    )
//
//------------------------------------------------

    // Draws this object on the passed Graphics context
    public void draw(Graphics g) {

        g.setColor(Color.blue);
        g.fillRect(centerPoint.x-100, centerPoint.y-100, 200, 200);

  //    g.fillRoundRect(centerPoint.x-100, centerPoint.y-100, 200, 200, 50, 50);

    }


    // Returns the center point of this drawable shape.
    public Point getCenterPoint( ) {

        return centerPoint;
    }


    // Returns the dimension of this shape.
    public Dimension getDimension( ) {

       return new Dimension(200,200);
    }


    // Sets the center point of this drawable shape.
    public void setCenterPoint(Point point) {

        centerPoint = point;
    }

}