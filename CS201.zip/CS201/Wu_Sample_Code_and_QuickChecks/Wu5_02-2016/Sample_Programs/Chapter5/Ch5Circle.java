/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 5 Sample Program: The Circle class

    File: Ch5Circle.java
*/

/*
  A sample class illustrating the use of if statements. This
  can compute the area and circumference of a circle
  given the radius. If an invalid value is set for the radius
  then INVALID_DIMENSION is returned when getArea or
  getCircumference is called.
*/

class Ch5Circle {

//----------------------------------
//    Data Members
//----------------------------------

    // Constant for invalid radius 
    public static final int INVALID_DIMENSION = -1;

    // Radius of this circle 
    private double radius;

//----------------------------------
//    Constructor
//----------------------------------

    // Constructs a circle with the passed radius.
    public Ch5Circle(double r) {
        setRadius(r);
    }

//-------------------------------------------------
//      Public Methods:
//
//          double  getArea         (           )
//          double  getCircumference(           )
//          double  getDiameter     (           )
//          double  getRadius       (           )
//
//          void    setDiameter     ( double    )
//          void    setRadius       ( double    )
//
//------------------------------------------------

    /*
      Returns the area of this circle if it has
      a valid radius. Returns INVALID_DIMENSION
      if the value for radius is invalid.
    */
    public double getArea( ) {

        double result = INVALID_DIMENSION;

        if (isRadiusValid())  {

            result = Math.PI * radius * radius;
        }

        return result;
    }


    /*
      Returns the circumference of this circle if it has
      a valid radius. Returns INVALID_DIMENSION
      if the value for radius is invalid.
    */
    public double getCircumference( ) {

        double result = INVALID_DIMENSION;

        if (isRadiusValid()) {

            result = 2.0 * Math.PI * radius;
        }

        return result;
    }


    /*
      Returns the diameter of this circle if it has
      a valid radius. Returns INVALID_DIMENSION
      if the value for radius is invalid.
    */
    public double getDiameter( ) {

        double diameter = INVALID_DIMENSION;

        if (isRadiusValid()) {

            diameter = 2.0 * radius;
        }

        return diameter;
    }


    /*
      Returns the radius of this circle.
      Returns INVALID_DIMENSION
      if the value for radius is invalid.
    */
    public double getRadius( ) {
        return radius;
    }


    /*
      Sets the diameter of this circle.
    */
    public void setDiameter(double d) {

        if (d > 0) {
            setRadius(d/2.0);
        } else {
            setRadius(INVALID_DIMENSION);
        }
    }


    /*
      Sets the radius of this circle.     
    */
    public void setRadius(double r) {

        if (r > 0) {
            radius = r;
        } else {
            radius = INVALID_DIMENSION;
        }
    }


//-------------------------------------------------
//      Private Methods:
//
//          boolean  isRadiusValid     (           )
//
//------------------------------------------------


    /*
      Returns true if the value set for
      radius is valid. Returns false otherwise
    */
    private boolean isRadiusValid( ) {

        return radius != INVALID_DIMENSION;
    }

}