/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 15 Sample Program: Test all sample recursive methods
                               discussed in Chapter 15

    File: TestCh15Algorithms.java

*/

import java.io.*;
import java.util.*;

/**
 * The main program to test the Ch 15 recursive algorithms.
 *
 */
class TestCh15Algorithms {

//--------------------------------
//  Data Members
//--------------------------------

    /**
     * A NL (new line) constant
     */
    private static final String NL = System.getProperty("line.separator");

    /**
     * The Ch15Algorithms object for running the selected algorithm
     */
    private Ch15Algorithms algorithmRunner;
    
    /**
     * Console input
     */
    private Scanner scanner;

//--------------------------------
//  Constructors
//--------------------------------

    /**
     * Default constructor.
     */
    public TestCh15Algorithms() {
        algorithmRunner = new Ch15Algorithms( );
        scanner = new Scanner(System.in);
    }



    public static void main( String[] args ) {
        TestCh15Algorithms driver = new TestCh15Algorithms(  );
        driver.start( );
    }


    public void start( ) {
        int selection;

        do {

            selection = getSelection( );

            switch ( selection ) {

                case 1: runFactorial( );
                        break;

                case 2: runDirList( );
                        break;

                case 3: runAnagram( );
                        break;

                case 4: runTowersOfHanoi( );
                        break;

                case 5: runQuickSort( );
                        break;

            }
        } while ( selection != 0 );

        System.exit(0);
    }

    private void runFactorial( ) {
        int N;

        while (true) {
        	System.out.println("Compute N! Enter N:" );
            N = scanner.nextInt();

            if (N > 0) break;

            System.out.println("N must be positive" );
        }

        int answer = algorithmRunner.factorial(N);

        System.out.println(NL + NL);
        System.out.println("Factorial of " + N + " is " + answer);
    }

    private void runDirList( ) {
    	
    	System.out.println("Enter the folder name");
        String dirName = scanner.next();

        File file = new File(dirName);

        System.out.println(NL + NL);

        algorithmRunner.directoryListing(file);
    }

    private void runAnagram( ) {
    	
    	System.out.println( "Generate anagrams. Enter a word" );
        String word = scanner.next();

        System.out.println(NL + NL);

        algorithmRunner.anagram("", word);
    }

    private void runTowersOfHanoi( ) {
    	
    	System.out.println("Towers of Hanoi. How many disks?");
        int diskCnt = scanner.nextInt();

        System.out.println(NL + NL);

        //algorithmRunner.towersOfHanoi(diskCnt, 1, 3, 2);
        algorithmRunner.towersOfHanoi(diskCnt, 1, 3, 2, 0);
    }

    private void runQuickSort( ) {
    	
    	System.out.println("Quicksort. Number of elements to sort:");
        int N = scanner.nextInt();

        System.out.println(NL + NL);
        System.out.println(" Unsorted List: ");


        //generate random numbers from 1 to N
        int[] list = new int[N];

        for (int i = 1; i < N; i++) {
            list[i] = (int) Math.floor(Math.random( ) * N) + 1;
            System.out.print("  " + list[i]);
        }

        //now sort the list
        algorithmRunner.quickSort(list, 0, N-1);

        System.out.println(NL + NL);
        System.out.println(" Sorted List: ");

        for (int i = 1; i < N; i++) {
            System.out.print("  " + list[i]);
        }
    }

    private int getSelection( ) {
        int selection;

        String menu = NL + NL +
        				"Select Algorithm:"       + NL +
                        "   1) Factorial"         + NL +
                        "   2) Directory Listing" + NL +
                        "   3) Anagram"           + NL +
                        "   4) Towers of Hanoi"   + NL +
                        "   5) Quicksort"         + NL +
                        "   -------------------"  + NL +
                        "   0) Quit"              + NL;


        System.out.println(menu);
        selection = scanner.nextInt();

        return selection;
    }
}


