/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill
    
    Wu/Otani

    File: Element.java

 */

class Element {

	// Data Member
	private String name;
	private int    number;
	private String symbol;
	private double mass;
	private int    period;
	private int    group;

	// Constructor
	public Element(String elementName, int elementNumber, String elementSymbol,
			double elementMass, int elementPeriod, int elementGroup) {

		name   = elementName;
		number = elementNumber;
		symbol = elementSymbol;
		mass   = elementMass;
		period = elementPeriod;
		group  = elementGroup;
	}

	// Returns the element's name
	public String getName() {
		return name;
	}

	// Returns the element's atomic number
	public int getNumber() {
		return number;
	}

	// Returns the element's 2-letter symbol
	public String getSymbol() {
		return symbol;
	}

	// Returns the element's atomic mass
	public double getMass() {
		return mass;
	}

	// Returns the element's period
	public int getPeriod() {
		return period;
	}

	// Returns the element's group
	public int getGroup() {
		return group;
	}
}
