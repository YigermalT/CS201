/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    File: AccountVer4.java

*/

//This version modifies AccountVer3 by adding a new private method adjust

class AccountVer4 {

    // Data Members   
    private static final double FEE = 0.50; //50 cents charge
    
    private String ownerName;
    
    private double balance;
    
    //Constructor
    public AccountVer4(String name, double startingBalance ) {

        ownerName = name;
        balance = startingBalance;
    }
    
    //Adds the passed amount to the balance
    public void add(double amt) {
       adjust(amt);
    }
    
    //Deducts the passed amount from the balance
    public void deduct(double amt) {
        adjust( -(amt+FEE) );
    }
    
    //Returns the current balance of this account
    public double getCurrentBalance( ) {
        return balance;
    }
    
    //Returns the name of this account's owner
    public String getOwnerName( ) {
        
        return ownerName;
    }
    
    //Assigns the name of this account's owner
    public void setOwnerName(String name) {
    
        ownerName = name;
    }   
    
    //Adust the account balance
    private void adjust(double adjustAmt) {
        balance = balance + adjustAmt;
    }
 }