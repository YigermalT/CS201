// Loan Class (Step 1)

/*
   Introduction to OOP with Java (5th Ed), McGraw-Hill
  
   Wu/Otani
  
   Chapter 4 Sample Development: Loan Calculation (Step 1)
  
   File: Step1/Loan.java
  
   This class handles the loan computation.
 
*/

class Loan {

//----------------------------------
//    Data Members
//----------------------------------



//----------------------------------
//    Constructors
//----------------------------------

     // Default contructor.
    public Loan( ) {


    }

}