
/*
  Introduction to OOP with Java (5th Ed), McGraw-Hill
 
  Wu/Otani
 
  Chapter 4 Sample Development: Loan Calculation (Step 1)
 
  File: Step1/LoanCalculator.java
 
  This class controls the input, computation, and output of loan
  
*/
class LoanCalculator {

//----------------------------------
//    Data Members
//----------------------------------

     // This object does the actual loan computation
    private Loan loan;

//----------------------------------
//
//  Main Method
//
//----------------------------------

    public static void main(String[] arg) {
        
        LoanCalculator calculator = new LoanCalculator();
        calculator.start();
    }

//----------------------------------
//    Constructors
//----------------------------------

    public LoanCalculator() {
        loan = new Loan();
    }

//-------------------------------------------------
//      Public Methods:
//
//          void start (        )
//
//------------------------------------------------

    //Top-level method that calls other private methods
    public void start() {

        describeProgram();   //tell what the program does
        getInput();          //get three input values
        computePayment();    //compute the monthly payment and total
        displayOutput();     //display the results
    }


//-------------------------------------------------
//      Private Methods:
//
//      void    computePayment    (        )
//      void    describeProgram   (        )
//      void    displayOutput     (        )
//      void    getInputs         (        )
//
//------------------------------------------------


    // Computes the monthly and total loan payments.
    private void computePayment() {
        System.out.println("inside computePayment");   //TEMP
    }


    // Provides a brief explanation of the program to the user.
    private void describeProgram() {
        System.out.println("inside describeProgram");   //TEMP
    }


    //Display the input values and monthly and total payments.
    private void displayOutput() {
        System.out.println("inside displayOutput");   //TEMP
    }


    // Gets three input values--loan amount, interest rate, and
    //  loan period--using an InputBox object
    private void getInput() {
        System.out.println("inside getInput");   //TEMP
    }

}