/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    File: BicycleWithMain/Bicycle.java

*/

//The modified Bicycle class with the main method included

class Bicycle {

    // Data Member   
    private String ownerName;
    
    //Constructor
    public Bicycle( ) {
        ownerName = "Unassigned";
    }
    
    //Returns the name of this bicycle's owner
    public String getOwnerName( ) {
        
        return ownerName;
    }

    //Assigns the name of this bicycle's owner
    public void setOwnerName(String name) {
    
        ownerName = name;
    }   
    
    //The main method that shows a sample
    //use of the Bicycle class 
    public static void main(String[] arg) {
        
        Bicycle myBike;
        
        myBike = new Bicycle();
        
        myBike.setOwnerName("Jon Java");
        
        System.out.println(myBike.getOwnerName() + " owns a bicycle");
    }
 }