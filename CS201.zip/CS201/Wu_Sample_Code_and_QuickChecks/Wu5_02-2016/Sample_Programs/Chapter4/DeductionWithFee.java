/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    File: DeductionWithFee.java

*/

import java.text.*;

class DeductionWithFee {
    
    //This sample program deducts money three times
    //from the account

    public static void main( String[] args ) {
    
        DecimalFormat df = new DecimalFormat("0.00");
        AccountVer3 acct;
        
        
        acct = new AccountVer3("Carl Smith", 50.00 );
        
        acct.deduct(10);
        acct.deduct(10);
        acct.deduct(10);
        System.out.println("Owner: " + acct.getOwnerName());
        System.out.println("Bal  : $" + df.format(acct.getCurrentBalance()));
    }
}