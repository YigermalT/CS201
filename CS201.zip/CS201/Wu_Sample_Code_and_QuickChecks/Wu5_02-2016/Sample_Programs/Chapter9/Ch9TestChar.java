/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Program: Char data type operations

    File: Ch9TestChar.java

*/


class Ch9TestChar {
    
    public static void main (String[] args) {

        System.out.println("ASCII code of character X is " + (int)'X' );

        System.out.println("Character with ASCII code 88 is " + (char)88 );
    }
}