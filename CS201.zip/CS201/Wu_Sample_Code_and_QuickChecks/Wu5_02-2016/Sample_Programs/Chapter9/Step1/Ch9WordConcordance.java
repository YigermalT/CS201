/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Development: Word Concordance

    File: Step1/Ch9WordConcordance.java

*/


/**
 *   class Ch9WordConcordance (Step 1)
 *
 *   The word list builder class.
 *
 * @author Dr. Caffeine
 */

class Ch9WordConcordance  {

//----------------------------------
//    Data Members
//----------------------------------



//----------------------------------
//      Sample main method
//----------------------------------

//----------------------------------
//    Constructors
//----------------------------------

    /**
     * Default constructor
     */
    public Ch9WordConcordance() {

    }

//----------------------------------
//    Private Methods
//
//          void start(     )
//
//----------------------------------


}