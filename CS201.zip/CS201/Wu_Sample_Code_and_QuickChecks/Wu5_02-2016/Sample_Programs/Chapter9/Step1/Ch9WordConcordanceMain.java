/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Development: Word Concordance

    File: Step1/Ch9WordConcordanceMain.java
*/

import java.util.*;

/**
 *   class Ch9WordConcordanceMain (Step 1)
 *
 *   The skeleton class for Step 1.
 *
 */
class Ch9WordConcordanceMain  {

//----------------------------------
//    Data Members
//----------------------------------
    private static enum Response {YES, NO}
    
    /** File manager for opening and saving a file */
    private FileManager fileManager;

    /** Word concordance builder */
    private Ch9WordConcordance builder;
    
    /** Scanner for getting input*/
    private Scanner scanner;


//----------------------------------
//      Sample main method
//----------------------------------
    public static void main(String[] args) {
        Ch9WordConcordanceMain main = new Ch9WordConcordanceMain();
        main.start();
    }

//----------------------------------
//    Constructors
//----------------------------------

    /**
     * Default constructor
     */
    public Ch9WordConcordanceMain() {

        fileManager = new FileManager( );
        builder     = new Ch9WordConcordance( );
        
        scanner     = new Scanner(System.in);
    }

//----------------------------------
//    Private Methods
//
//          void start(     )
//
//----------------------------------

    /**
     * Top level control
     */
    private void start( ) {
        
        Response userReply;

        while (true) {

            userReply = prompt("Run the program?");
            
            if (userReply == Response.NO) {
                break;
            }
        }

        System.out.println("Thank you for using the program. Good-Bye");
    }
    
    private Response prompt(String question) {

        String input;

        Response response = Response.NO;

        System.out.print(question + " (Yes - y; No - n): ");

        input = scanner.next();

        if (input.equals("Y") || input.equals("y")) {
            response = Response.YES;
        }

        return response;
    }
}