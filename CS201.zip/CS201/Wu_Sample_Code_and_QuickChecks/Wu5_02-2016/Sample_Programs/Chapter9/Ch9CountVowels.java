/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Program: Count the number of vowels
                                in a given string

    File: Ch9CountVowels.java
*/

import java.util.*;

class Ch9CountVowels {

    public static void main (String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        scanner.useDelimiter(System.getProperty("line.separator"));

        String    name;

        int       numberOfCharacters,
                  vowelCount = 0;

        char      letter;

        System.out.print("What is your name? ");
        name = scanner.next();

        numberOfCharacters = name.length();

        for (int i = 0; i < numberOfCharacters; i++) {

            letter = name.charAt(i);

            if (   letter == 'a' || letter == 'A' ||
                   letter == 'e' || letter == 'E' ||
                   letter == 'i' || letter == 'I' ||
                   letter == 'o' || letter == 'O' ||
                   letter == 'u' || letter == 'U'     ) {

                vowelCount++;
            }
        }

        System.out.println(name + ", your name has " +
                           vowelCount + " vowels");

    }
}