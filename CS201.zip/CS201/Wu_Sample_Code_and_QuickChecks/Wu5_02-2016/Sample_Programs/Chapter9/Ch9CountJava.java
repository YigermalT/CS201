/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Program:

            Count the number of times the word 'java' occurs
            in input. Case-insensitive comparison is used here.
            The program terminates when the word STOP (case-sensitive)
            is entered.

    File: Ch9CountJava.java
*/

import java.util.*;

class Ch9CountJava {

    public static void main (String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        int       javaCount  = 0;

        String    word;

        while (true) {

            System.out.print("Next word: ");
            word = scanner.next();

            if ( word.equals("STOP") )   {
                break;

            } else if ( word.equalsIgnoreCase("Java") ) {
                javaCount++;
            }
        }

        System.out.println("'Java' count: " + javaCount );
    }
}