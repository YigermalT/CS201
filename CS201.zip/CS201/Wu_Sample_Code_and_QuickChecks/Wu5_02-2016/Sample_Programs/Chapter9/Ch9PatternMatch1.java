/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Program: Using the matches method

    File: Ch9PatternMatch1.java
*/



class Ch9PatternMatch1 {

    public static void main (String[] args) {

        String  sentence, pattern;

        sentence = "If you truly want to master zen of objects, " +
                   "then you just have to get Dr. Caffeine's book An " +
                   "Introduction to Object-Oriented Programming with Java " +
                   "published from McGraw-Hill";

        pattern  = ".*zen of objects.*";

        System.out.println("The pattern '" + pattern + "' was");

        if (!sentence.matches(pattern)) {
            System.out.println(" NOT ");
        }

        System.out.println("found");
    }
}