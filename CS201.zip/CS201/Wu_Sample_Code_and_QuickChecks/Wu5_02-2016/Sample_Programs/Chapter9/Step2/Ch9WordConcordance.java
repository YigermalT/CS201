/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Development: Word Concordance

    File: Step2/Ch9WordConcordance.java

*/


/**
 *   class Ch9WordConcordance (Step 2)
 *
 *   The word list builder class.
 *
 */

class Ch9WordConcordance  {

//----------------------------------
//    Data Members
//----------------------------------



//----------------------------------
//      Sample main method
//----------------------------------

//----------------------------------
//    Constructors
//----------------------------------

    /**
     * Default constructor
     */
    public Ch9WordConcordance() {

    }

//----------------------------------
//    Public Methods
//
//          String build    ( String   )
//
//----------------------------------

    public String build(String document) {

        //for platform-independent line separator, do this:
        //
        //  String newline = System.getProperties().getProperty("line.separator");
        //  String list = "one 14" + newline + "two 3" + newline + "three 3" +
        //                newline + "four 5" + newline + "five 92" + newline;
        //
        //TEMP
        String list = "one 14\ntwo 3\nthree 3\nfour 5\nfive 92\n";

        return list;
        //TEMP
    }
}