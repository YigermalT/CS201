/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 9 Sample Program:

            Output the reverse sequence of a given DNA.

    File: Ch9ReverseDNA.java
*/

import java.util.*;

class Ch9ReverseDNA {

    public static void main (String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        String dna;
        StringBuffer result;

        while (true) {

            System.out.print("Next DNA Sequence: ");           
            dna = scanner.next();
            
            if (dna.equalsIgnoreCase("STOP") )   {
                break;
            }
            
            result = new StringBuffer(dna);
            result.reverse();
            
            System.out.println("RNA: " + result.toString());
            System.out.println("");            
        }
    }
}