/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 14 Sample Program: Displays a default Ch7JFrameSubclass window

    File: Ch14TestJFrameSubclass.java

*/

class Ch14TestJFrameSubclass {

    public static void main( String[] args ) {

        Ch14JFrameSubclass1 myFrame;

        myFrame = new Ch14JFrameSubclass1();

        myFrame.setVisible(true);
    }
}