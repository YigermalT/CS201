package student.abstract_deom;

public class GraduateStudent extends Student {
	public GraduateStudent(String name) {
		this.name = name;
	}
	
	@Override
	public void computeGPA() {
		System.out.println("Computing GPA for an undergrad studednt "+ name);
	}
}
