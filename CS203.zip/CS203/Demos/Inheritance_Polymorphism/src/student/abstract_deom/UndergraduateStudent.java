package student.abstract_deom;

public class UndergraduateStudent extends Student {
	
	public UndergraduateStudent(String name) {
		this.name = name;
	}
	
	@Override
	public void computeGPA() {
		System.out.println("Computing GPA for a graduate studednt "+ name);
	}
}
