// In almost all real life programs, main class is always on different package.
// I am intentionally doing for this demo as well otherwise it will be in same package as other classes
// and protected members are visible from any class within a package.
package student.abstract_deom.test;

import student.abstract_deom.GraduateStudent;
import student.abstract_deom.Student;
import student.abstract_deom.UndergraduateStudent;

public class StudentMain {
	public static void main(String[] args) {
		Student s1 = new UndergraduateStudent("Sam");
		Student s2 = new GraduateStudent("Sammy");
		
		// Since we added abstract method to the parent class there is no need for type casting now.
		s1.computeGPA();
		s2.computeGPA();
	}
}
