package student.abstract_deom;

// Whole class should be abstract as soon as we add a abastract method to a class.
public abstract class Student {
	private final int NUMBER_OF_COURSES = 3;
	
	// If the data member were not protected child classes had to depend on
	// public getters and setters, which won't make them feel at home :).
	protected String name;
	protected double[] grades = new double[NUMBER_OF_COURSES];
	protected double gpa;
	
	public abstract void computeGPA();
}
