package student.concrete;

public class Student {
	private final int NUMBER_OF_COURSES = 3;
	
	// If the data member were not protected child classes had to depend on
	// public getters and setters, which won't make them feel at home :).
	protected String name;
	protected double[] grades = new double[NUMBER_OF_COURSES];
	protected double gpa;
	
}
