package student.concrete;

public class GraduateStudent extends Student {
	public GraduateStudent(String name) {
		this.name = name;
	}
	
	public void computeGPA() {
		System.out.println("Computing GPA for a graduate studednt "+ name);
	}
}
