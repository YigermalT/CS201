// In almost all real life programs, main class is always on different package.
// I am intentionally doing for this demo as well otherwise it will be in same package as other classes
// and protected members are visible from any class within a package.
package student.concrete.test;

import student.concrete.GraduateStudent;
import student.concrete.Student;
import student.concrete.UndergraduateStudent;

public class StudentMain {
	public static void main(String[] args) {
		Student s1 = new UndergraduateStudent("Sam");
		Student s2 = new GraduateStudent("Sammy");
		
		((UndergraduateStudent)s1).computeGPA();
		((GraduateStudent)s2).computeGPA();
	}
}
