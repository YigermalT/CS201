package pet.concrete;

public class Dog extends Pet {

	@Override
	public void speak() {
		System.out.println(getName()+" says Woff woff!");
	}
	
	public void fetch() {
		System.out.println(getName()+ " says 'I am getting it...'");
	}
}
