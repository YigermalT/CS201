package pet.concrete;

public class Pet {
	private String name;
	
//	public Pet(String name) {
//		setName(name);
//	}

	public void speak() {
		System.out.println("I am your cuddly pet.");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
