package pet.concrete;

public class Cat extends Pet {
	@Override
	public void speak() {
		System.out.println(getName() + " says Meeooww!");;
	}
}
