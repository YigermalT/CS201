package pet.abstract_demo;

public class PetApp {
	public static void main(String[] args) {

//		Pet p0 = new Pet();

		Pet p1 = new Cat();
	
		p1.setName("Kittty");

		Pet p2 = new Dog();

		p2.setName("Doggy");


		p1.speak();
		
		p2.speak();
		
		
// p2 being reference of Pet, it only sees pet has.
		
((Dog)p2).fetch();
	}
}
