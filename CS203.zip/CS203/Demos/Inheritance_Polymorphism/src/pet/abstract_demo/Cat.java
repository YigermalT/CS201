package pet.abstract_demo;

public class Cat extends Pet {
	// Notice the annotation @Override
	@Override
	public void speak() {
		System.out.println(getName() + " says Meeooww!");;
	}
}
