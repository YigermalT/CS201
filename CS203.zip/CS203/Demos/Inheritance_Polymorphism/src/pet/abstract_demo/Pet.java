package pet.abstract_demo;

public abstract class Pet {
	
private String name;


// Abstract class can have constructors, you might ask why?

// yes, we won't create direct instance of an abstract class,

// still it's data members should be initialized.

// remember a constructor has two proposes.


//	public Pet(String name) {

//		this.name = name;

//	}
	
	
public void speak() {
		
System.out.println("I am your cuddly pet.");
	
}

	
public String getName() {
		
return name;
	}

	

public void setName(String name) {
		
this.name = name;
	}

}
