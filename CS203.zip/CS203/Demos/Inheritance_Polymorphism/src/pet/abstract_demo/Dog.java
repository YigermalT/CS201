package pet.abstract_demo;

public class Dog extends Pet {

	// Notice @Override annotation
	@Override
	public void speak() {
		System.out.println(getName()+" says Woff woff!");
	}
	
	// See what happens if you enable @Override below
	// @Override
	public void fetch() {
		System.out.println(getName()+ " says 'I am getting it...'");
	}
}
