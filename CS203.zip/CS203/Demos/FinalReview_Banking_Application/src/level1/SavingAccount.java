/**
 * 
 */
package level1;

import java.time.LocalDate;

/**
 * @author Rakesh Shrestha
 *
 */
public class SavingAccount extends Account {

	private static final int MAX_WITHDRAW_COUNT = 6;
	private int withdrawCount;
	
	public SavingAccount(int accountNo, double balance, double interestRate) {
		super(accountNo, balance, interestRate);
		this.withdrawCount = 0;
	}

	public void deposite(double amount) {
		this.balance += amount;
	}

	@Override
	public void withdraw(double amount) {
		if(withdrawCount <= MAX_WITHDRAW_COUNT && balance>amount) {
			balance = balance-amount;
		}
		withdrawCount++;
	}
	
}
