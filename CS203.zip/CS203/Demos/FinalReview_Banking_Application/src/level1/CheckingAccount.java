/**
 * 
 */
package level1;

import java.time.LocalDate;

public class CheckingAccount extends Account{
	private static final double MIN_BALANCE = 100;
	
	public CheckingAccount(int accountNo, double balance, double interestRate) {
		super(accountNo, balance, interestRate);
	}
	
	@Override
	public void deposite(double amount) {
		balance = balance + amount + 0.01*amount;
	}

	@Override
	public void withdraw(double amount) {
		double availableBalance = balance-MIN_BALANCE;
		if(amount <= availableBalance) {
			balance = balance - availableBalance;
		}
	}

}
