/**
 * 
 */
package level1;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class Customer {
	private String name;
	private LocalDate dob;
	private List<Account> accounts;
	public Customer(String name, LocalDate dob) {
		super();
		this.name = name;
		this.dob = dob;
		this.accounts = new ArrayList<>();
	}
	
	public void addAccount (Account account) {
		accounts.add(account);
	}
	
	public List<Account> getAllAcounts(){
		return accounts;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", dob=" + dob + "]";
	}
	
	
	
}
