/**
 * 
 */
package level1;

import java.time.LocalDate;

/**
 * @author Rakesh Shrestha
 *
 */
public class Bank {
	public static void main(String[] args) {
		Customer customer = new Customer("Rakesh Shrestha", LocalDate.of(1988, 9, 6));
		customer.addAccount(new CheckingAccount(1234, 1500, 1));
		customer.addAccount(new SavingAccount(2345, 300, 2));
		customer.getAllAcounts().get(0).deposite(500);
		System.out.println(customer.getAllAcounts().get(1).calculateInterestEarned(LocalDate.of(2019, 5, 24)));
		
		CustomerDatabase customerDatabase = new CustomerDatabase();
		customerDatabase.addCustomer(customer);
		
		for(Customer c: customerDatabase.getAllCustomers()) {
			System.out.println(c);
			for(Account a: c.getAllAcounts()) {
				System.out.println("\t"+a);
			}
			System.out.println();
		}
	}
}
