/**
 * 
 */
package level1;

import java.time.LocalDate;

/**
 * @author Rakesh Shrestha
 *
 */
public abstract class Account {
	protected LocalDate openDate;
	protected int accountNo;
	protected double balance;
	protected double interestRate;
	
	
	public Account(int accountNo, double balance, double interestRate) {
		super();
		this.openDate = LocalDate.now();
		this.accountNo = accountNo;
		this.balance = balance;
		this.interestRate = interestRate;
	}
	public abstract void deposite(double amount);
	public abstract void withdraw(double amount);
	
	public double calculateInterestEarned(LocalDate date) {
		int years = openDate.until(date).getYears();
		int months = openDate.until(date).getMonths();
		int days = openDate.until(date).getDays();
		double timeInYears = years + (months/12.0)+(days/365.0);
		return balance*timeInYears*interestRate/100;
	}
	
	@Override
	public String toString() {
		return "Account [openDate=" + openDate + ", accountNo=" + accountNo + ", balance=" + balance + ", interestRate="
				+ interestRate + "]";
	}
	
	
}
