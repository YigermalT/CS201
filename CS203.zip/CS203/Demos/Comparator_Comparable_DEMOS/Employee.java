import java.util.Date;

public class Employee {
	private String firstName;
	private Date hireDate;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	
	public Employee(String name) {
		this.firstName = name;
	}
	
	@Override
	public String toString() {
		return this.firstName;
	}
	
	
}
