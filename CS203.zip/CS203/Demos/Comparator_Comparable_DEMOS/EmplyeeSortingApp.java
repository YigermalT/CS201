import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmplyeeSortingApp {
	public static void main(String[] args) {
//		Employee[] empArray = {
//				new Employee("George"),
//				new Employee("Dave"),
//				new Employee("Richard")
//		};
//		
//		List<Employee> empList = Arrays.asList(empArray);
//		Comparator<Employee> nameComp = new NameComparator();
//		System.out.println(empList);
//		Collections.sort(empList, nameComp);
//		System.out.println(empList);
		
		CompareableEmployee[] empArray = {
				new CompareableEmployee("George"),
				new CompareableEmployee("Dave"),
				new CompareableEmployee("Richard")
		};
		
		List<CompareableEmployee> empList = Arrays.asList(empArray);
		System.out.println(empList);
		Collections.sort(empList);
		System.out.println(empList);
	}
	
}
