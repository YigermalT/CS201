import java.util.Date;

public class CompareableEmployee implements Comparable<CompareableEmployee>{
	private String firstName;
	private Date hireDate;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	
	public CompareableEmployee(String name) {
		this.firstName = name;
	}
	
	@Override
	public String toString() {
		return this.firstName;
	}
	@Override
	public int compareTo(CompareableEmployee e1) {
		return this.firstName.compareTo(e1.firstName);
	}
	
	
}
