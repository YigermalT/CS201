package level1;

import java.util.ArrayList;
import java.util.List;

public class LibraryDataBase {
	
	private static  List<LibraryMember>  libraryMemberList = new ArrayList<>();
	
	public static void addLibraryMember(LibraryMember libraryMember) {
		libraryMemberList.add(libraryMember);	
	}
	
	public static  List<LibraryMember> getLibraryMember() {
		return libraryMemberList; 
	}

}
