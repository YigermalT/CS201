package level1;

import java.time.LocalDate;

public class libraryApplication {

	public static void main(String[] args) {

		StudentMember sM1 = new StudentMember(123, "Yigermal", "A");
		sM1.addBookList(new Book(113, "Java for Dummies", 0.25, 10, LocalDate.of(2018, 2, 25)));
		sM1.addBookList(new Book(124, "Inro to Java", 0.21, 10, LocalDate.of(2018, 2, 25)));
		LibraryDataBase.addLibraryMember(sM1);
		EmployeeMember eM1 = new EmployeeMember(344, "Josh",  5);
		eM1.addBookList(new Book(115, "How to get Employeed", 0.27, 10, LocalDate.of(2018, 2, 25)));
		eM1.addBookList(new Book(116, "Get Hired", 0.27, 10, LocalDate.of(2018, 2, 25)));
		LibraryDataBase.addLibraryMember(eM1);
		
		for (LibraryMember s: LibraryDataBase.getLibraryMember()) {
			if (s instanceof StudentMember) {
				System.out.println(sM1);
				sM1.ComputeTotalCharge(LocalDate.now());
				System.out.println("\t"+ "Total Charge " + sM1.ComputeTotalCharge(LocalDate.now()));
			} else if (s instanceof EmployeeMember) {
				System.out.println(eM1);
				sM1.ComputeTotalCharge(LocalDate.now());
				System.out.println("\t "+"Total Charge " + sM1.ComputeTotalCharge(LocalDate.now()));
			}
			
		}
		
	}
}
