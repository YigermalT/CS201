package level2;

import java.time.LocalDate;
import java.util.List;

public class StudentMember extends LibraryMember {

	private String LastSemesterGrade;

	public StudentMember(int memberId, String name, String lastSemesterGrade) {
		super(memberId, name, bookList);
		LastSemesterGrade = lastSemesterGrade;
	}
	public StudentMember() {
		
	}
	

	@Override
	public  double ComputeTotalCharge(LocalDate returnDate) {
		double totalcharge = bookList.size(); 
		if ("AH".equalsIgnoreCase(LastSemesterGrade)) {
			totalcharge = 0.00;
		}
		return totalcharge;
	}

	@Override
	public String toString() {
		
		return "Student Member  [" +  "LastSemesterGrade" + "\t" + LastSemesterGrade + 
				", " + "memberId  "+ memberId + "Name: " + name+ "]";
	} 
	
	
}
