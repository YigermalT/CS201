package level2;

import java.time.LocalDate;
import java.util.List;

public class EmployeeMember extends LibraryMember {
	private int yearsOfService;

	public  EmployeeMember() {
		
	}
	public EmployeeMember(int memberId, String name, int yearsOfService) {
		super(memberId, name, bookList);
		this.yearsOfService = yearsOfService;
	}

	@Override
	double ComputeTotalCharge(LocalDate returnDate) {

		double totalcharge = bookList.size();
		if (yearsOfService > 5) {
			totalcharge = totalcharge * 0.5;
		}
		return totalcharge;

	}

	@Override
	public String toString() {
		return "Employee Member  [" +  "LastSemesterGrade" + "\t" + yearsOfService + 
				", " + "memberId  "+ memberId + "Name: " + name+ "]";
	} 
	
	

}
