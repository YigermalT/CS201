package level3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LibraryDataBase implements Serializable{

	private static List<LibraryMember> libraryMemberList = new ArrayList<>();

	public static void addLibraryMember(LibraryMember libraryMember) throws ClassNotFoundException, IOException {
			libraryMemberList.add(libraryMember);
	}

	public static List<LibraryMember> readLibraryMember() throws ClassNotFoundException, IOException {
		readFile();
		return libraryMemberList;
	}

	public static void saveFile() throws IOException {
		File file = new File("C:\\Users\\abush\\Desktop\\members.dat");
		FileOutputStream fileO = new FileOutputStream(file);
		ObjectOutputStream oOut = new ObjectOutputStream(fileO);
		oOut.writeObject(libraryMemberList);
		oOut.close();
	}

	@SuppressWarnings("unchecked")
	public static void readFile() throws IOException, ClassNotFoundException {
		File file = new File("C:\\Users\\abush\\Desktop\\members.dat");
		if (file.exists()) {
			FileInputStream fIN = new FileInputStream(file);
			ObjectInputStream oIn = new ObjectInputStream(fIN);
			libraryMemberList = (List<LibraryMember>) oIn.readObject();
			oIn.close();
		}
	}
}
