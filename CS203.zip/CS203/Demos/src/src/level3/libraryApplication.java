package level3;

import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class libraryApplication implements Serializable{

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		List<LibraryMember> existMember = new ArrayList<>(); 
		try {
			existMember = LibraryDataBase.readLibraryMember();
		} catch (Exception e) {
			// TODO: handle exception
		} 
		
		
		
		StudentMember sM1 = new StudentMember();;
		EmployeeMember eM1 = new EmployeeMember();
		
		Scanner scanner = new Scanner(System.in);
		boolean condition = true; 
		System.out.println("Enter Members info: ");
		System.out.println("Enter S for StudentMembers or E for Employee or N for quit: ");
		while (condition) {
			
			
			String str = scanner.next();
			if (str.equalsIgnoreCase("S")) {
				System.out.println("Enter the MemberID: ");
				int memberId = scanner.nextInt();
				System.out.println("Enter the Name: ");
				String name = scanner.next();
				System.out.println("Enter the lastSemesterGrade: ");
				String lastSemesterGrade = scanner.next();
				System.out.println("Enter the isbn: ");
				int isbn = scanner.nextInt();
				System.out.println("Enter the Book Title: ");
				String title = scanner.next();
				System.out.println("Enter  chargePerDay: ");
				double chargePerDay = scanner.nextDouble();
				System.out.println("Enter  Max charge: ");
				double maxCharge = scanner.nextDouble();
				System.out.println("Enter  the issue Date: ");
				String issueDate = scanner.next();
				
				String[] parts = issueDate.split("/"); 
				
				sM1 = new StudentMember(memberId, name, lastSemesterGrade);
				LibraryMember.addBookList(new Book(isbn,title, chargePerDay, maxCharge, LocalDate.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]))));
				existMember.add(sM1);
				System.out.println("Enter S for StudentMembers or E for Employee or N for quit: ");
			}
			
			if (str.equalsIgnoreCase("E")) {
				System.out.println("Enter the MemberID: ");
				int memberId = scanner.nextInt();
				System.out.println("Enter the Name: ");
				String name = scanner.next();
				System.out.println("Enter Years Of Service: ");
				String lastSemesterGrade = scanner.next();
				System.out.println("Enter the isbn: ");
				int isbn = scanner.nextInt();
				System.out.println("Enter the Book Title: ");
				String title = scanner.next();
				System.out.println("Enter  chargePerDay: ");
				double chargePerDay = scanner.nextDouble();
				System.out.println("Enter  Max charge: ");
				double maxCharge = scanner.nextDouble();
				System.out.println("Enter  the issue Date: ");
				String issueDate = scanner.next();
				String[] parts = issueDate.split("/"); 
				eM1 = new EmployeeMember(344, "Josh",  5);
				LibraryMember.addBookList(new Book(isbn,title, chargePerDay, maxCharge, LocalDate.of(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), Integer.parseInt(parts[2]))));
				existMember.add(eM1);
				System.out.println("Enter S for StudentMembers or E for Employee or N for quit: ");
			}
			if (str.equalsIgnoreCase("N")) {
				scanner.close();
				LibraryDataBase.saveFile();
				System.out.println("fileSaved");
				LibraryDataBase.readLibraryMember();
				break;
			}

		}
		
		for (LibraryMember s: LibraryDataBase.readLibraryMember()) {
			if (s instanceof StudentMember) {
				System.out.println(sM1);
				sM1.ComputeTotalCharge(LocalDate.now());
				System.out.println("\t"+ "Total Charge " + sM1.ComputeTotalCharge(LocalDate.now()));
			} else if (s instanceof EmployeeMember) {
				System.out.println(eM1);
				sM1.ComputeTotalCharge(LocalDate.now());
				System.out.println("\t "+"Total Charge " + sM1.ComputeTotalCharge(LocalDate.now()));
			}
			
		}
		
	}
}
