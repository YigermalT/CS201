package level3;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Book {
	private int isbn;
	private static String title;
	private static double chargePerDay;
	private static double maxCharge;
	private static LocalDate issueDate;

	public Book(int isbn, String title, double chargePerDay, double maxCharge, LocalDate issueDate) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.chargePerDay = chargePerDay;
		this.maxCharge = maxCharge;
		this.issueDate = issueDate;
	}

	public static double ComputeCharge(LocalDate returnDate) {
		double totalcharge = 0.00;
		long days = ChronoUnit.DAYS.between(issueDate, returnDate);
		totalcharge = days * (long) chargePerDay;
		if (totalcharge > maxCharge) {
			totalcharge = maxCharge;
		}
		return totalcharge;
	}
}
