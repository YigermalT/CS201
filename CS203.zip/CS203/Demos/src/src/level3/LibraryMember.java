package level3;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class LibraryMember implements Serializable {
	
	protected static int memberId;
	protected static String name;
	protected  static  List<Book> bookList = new ArrayList<Book>();
	
	public LibraryMember() {
		
	}
	
	
	public LibraryMember(int memberId, String name, List<Book> bookList) {
		super();
		this.memberId = memberId;
		this.name = name;
		this.bookList = bookList;
	}

public static void addBookList(Book book) {
	bookList.add(book);
}

public static List<Book> readBookList(){
	return bookList; 
	
}


	abstract double ComputeTotalCharge(LocalDate returnDate);		
	
	
	
	
	
	
}
