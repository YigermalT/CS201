package Bankk;

import java.time.LocalDate;

public class CheckingAcct extends Account{

	public static final int minBalance = 100;
	public CheckingAcct(LocalDate openDate, int accountNo, double balance, double interestRate) {
		super(openDate, accountNo, balance, interestRate);
		
	}
	@Override
	void deposit(double depositAmount) {
		
		balance = balance + (depositAmount*1.01);
	}
	@Override
	void withdraw(double withdrawAmount) {
		
		if (balance <= withdrawAmount) {
			System.out.println("you can't exceed your minimum balance!");
		} else {balance = balance - withdrawAmount;}
		
	}

	
}
