package Bankk;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Customer {
	private String name;
	private LocalDate dob;
	private List<Account> accountList = new ArrayList<>();

	public Customer(String name, LocalDate dob) {
		super();
		this.name = name;
		this.dob = dob;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public List<Account> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}

	public void addAcct(Account e) {
		accountList.add(e);
	}

	public List<Account> readAllAcct() {
		return accountList;
	}

	@Override
	public String toString() {
			return "Customer Name: " + name + "\t" +  "Date of Birth: "+"\t"+ dob; 
	}
	
	
}
