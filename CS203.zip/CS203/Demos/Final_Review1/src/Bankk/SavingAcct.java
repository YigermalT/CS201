package Bankk;

import java.time.LocalDate;

public class SavingAcct  extends Account {
private static int withdrawCount = 0; 
	public SavingAcct(LocalDate openDate, int accountNo, double balance, double interestRate) {
		super(openDate, accountNo, balance, interestRate);
	}
	@Override
	void deposit(double depositAmount) {
		balance = balance + depositAmount;
		
	}
	@Override
	void withdraw(double withdrawAmount) {
		if (withdrawCount < 6 ) {
			balance = balance - withdrawAmount;
			withdrawCount++;
		}
		
	}
	

}
