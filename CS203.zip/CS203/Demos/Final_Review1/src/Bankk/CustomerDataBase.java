package Bankk;

import java.util.ArrayList;
import java.util.List;

public class CustomerDataBase {
	private static List<Customer> customerList = new ArrayList<>();

	public static void addCustomer(Customer custoemr) {
		customerList.add(custoemr);
	}

	public static List<Customer> readcustomerslist() {
		return customerList;

	}
}
