package Bankk;

import java.time.LocalDate;

public abstract class Account {

	private LocalDate openDate;
	private int accountNo;
	public double balance;
	private double  interestRate;
	
	public Account(LocalDate openDate, int accountNo, double balance, double interestRate) {
		super();
		this.openDate = openDate;
		this.accountNo = accountNo;
		this.balance = balance;
		this.interestRate = interestRate;
	}

	public LocalDate getOpenDate() {
		return openDate;
	}

	public void setOpenDate(LocalDate openDate) {
		this.openDate = openDate;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	
	public void interestRate() {
		
	}

	abstract void deposit(double depositAmount); 
	
	
	abstract void  withdraw(double withdrawAmount);

	@Override
	public String toString() {
		return "Account info: " + " Opendate: "+ openDate + "\t" + " Account No.: " 
				+accountNo + "\t" + "Balance: " + "\t" + balance+ "\t "+ "InterestRate: "+ "\t"+ interestRate;
	}
	
	
}
