package Level4;

import java.io.Serializable;
import java.time.LocalDate;

public class Person implements Serializable {
	private String name;
	private LocalDate dob;
	private Address address;

	public Person() {
		this("Unknown", null, null);
	}

	public Person(String name, LocalDate dob, Address address) {
		super();
		this.name = name;
		this.dob = dob;
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", dob=" + dob + ", address=" + address + "]";
	}
}
