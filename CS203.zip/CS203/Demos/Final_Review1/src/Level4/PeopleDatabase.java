package Level4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class PeopleDatabase {
	private static List<Person> people = new ArrayList<>();

	public static void addPerson(Person person) {
		people.add(person);
	}

	public static void SaveToFile() throws IOException, ClassNotFoundException {
		File file = new File("people_gui.dat");
		
		FileOutputStream fOutStream = new FileOutputStream(file);
		ObjectOutputStream objOutStream = new ObjectOutputStream(fOutStream);
		objOutStream.writeObject(people);
		objOutStream.close();
	}

	public static void restorePeopleFromFile() throws IOException, ClassNotFoundException {
		File file = new File("people_gui.dat");
		if (file.exists()) {
			FileInputStream fInStream = new FileInputStream(file);
			ObjectInputStream objInStream = new ObjectInputStream(fInStream);
			people = (List<Person>) objInStream.readObject();
			objInStream.close();
		}
	}
	
	public static List<Person> getPeople(){
		return people;
	}
}
