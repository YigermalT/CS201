package Level4;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddPersonFrame extends JFrame implements ActionListener {

	JTextField nameField, dobField, streetField, cityField, stateField, zipField;

	public AddPersonFrame() {
		setTitle("Add Person");
		setSize(150, 400);
		setLocation(300, 300);
		JLabel namePrompt = new JLabel("Name: ");
		nameField = new JTextField(10);
		JLabel dobPrompt = new JLabel("Date of Birth: ");
		dobField = new JTextField(10);
		JLabel streetPrompt = new JLabel("Street: ");
		streetField = new JTextField(10);
		JLabel cityPrompt = new JLabel("City: ");
		cityField = new JTextField(10);
		JLabel statePrompt = new JLabel("State: ");
		stateField = new JTextField(10);
		JLabel zipPrompt = new JLabel("ZIP: ");
		zipField = new JTextField(10);

		JButton addButton = new JButton("ADD");
		addButton.addActionListener(this);
		JButton saveButton = new JButton("SAVE TO FILE");
		saveButton.addActionListener(this);

		setLayout(new FlowLayout());
		add(namePrompt);
		add(nameField);
		add(dobPrompt);
		add(dobField);
		add(streetPrompt);
		add(streetField);
		add(cityPrompt);
		add(cityField);
		add(statePrompt);
		add(stateField);
		add(zipPrompt);
		add(zipField);
		add(addButton);
		add(saveButton);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if ("ADD".equals(command)) {
			String name = nameField.getText();
			String dob = dobField.getText();
			String[] splittedDOB = dob.split("/");
			String street = streetField.getText();
			String city = cityField.getText();
			String state = stateField.getText();
			String zip = zipField.getText();

			Address address = new Address(street, city, state, Integer.parseInt(zip));
			Person person = new Person(name, LocalDate.of(Integer.parseInt(splittedDOB[0]),
					Integer.parseInt(splittedDOB[1]), Integer.parseInt(splittedDOB[2])), address);
			Main.addPerson(person);
			System.out.println("Person added.");
		} else if ("SAVE TO FILE".equals(command)) {
			Main.saveToFile();
			System.out.println("Saved to file.");

			StringBuilder messageBuilder = new StringBuilder("");
			for (Person p : PeopleDatabase.getPeople()) {
				messageBuilder.append(p + "\n");
			}
			JOptionPane.showMessageDialog(this, messageBuilder.toString());

		}

	}

}
