package Level4;

import java.io.IOException;

public class Main {
	public static void main(String[] args) {
		try {
			PeopleDatabase.restorePeopleFromFile();
		} catch (ClassNotFoundException | IOException e1) {
			e1.printStackTrace();
		}

		AddPersonFrame addPersonFrame = new AddPersonFrame();

	}

	public static void addPerson(Person person) {
		PeopleDatabase.addPerson(person);
	}

	public static void saveToFile() {
		try {
			PeopleDatabase.SaveToFile();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}
