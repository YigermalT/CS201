package level1;

import java.awt.List;
import java.time.LocalDate;

public class Main {
	public static void main(String[] args) {
		Address a1 = new Address("2000 N Court", "Fairfield", "IA", 52556);
		Address a2 = new Address("1000 N 4th St", "Fairfield", "IA", 52557);
		
		Person p1 = new Person("John Kelly", LocalDate.of(1990, 11, 23), a1);
		Person p2 = new Person("Jimmy Carter", LocalDate.of(1888, 7, 16), a2);
		
		PeopleDatabase.addPerson(p1);
		PeopleDatabase.addPerson(p2);
		
		for(Person p: PeopleDatabase.getPeople()) {
			System.out.println(p);
		}
		
	}
}
