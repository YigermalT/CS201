package Bankk2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import level3.Person;

public class CustomerDataBase {
	private static List<Customer> customerList = new ArrayList<>();

	public static void addCustomer(Customer custoemr) {
		customerList.add(custoemr);
	}

	public static List<Customer> readcustomerslist() throws ClassNotFoundException, IOException {
		readCustomer();
		return customerList;

	}

	public static void SaveToFile() throws IOException, ClassNotFoundException {
		File file = new File("C:\\Users\\abush\\Desktop\\Bank.dat");

		FileOutputStream fOutStream = new FileOutputStream(file);
		ObjectOutputStream objOutStream = new ObjectOutputStream(fOutStream);
		objOutStream.writeObject(customerList);
		objOutStream.close();
	}

	@SuppressWarnings("unchecked")
	private static void readCustomer() throws IOException, ClassNotFoundException {
		File file = new File("C:\\Users\\abush\\Desktop\\Bank.dat");
		FileInputStream fInStream = new FileInputStream(file);
		@SuppressWarnings("resource")
		ObjectInputStream objInStream = new ObjectInputStream(fInStream);
		customerList = (List<Customer>) objInStream.readObject();
	}
}
