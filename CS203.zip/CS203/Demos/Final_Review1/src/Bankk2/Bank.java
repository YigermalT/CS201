package Bankk2;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Bank {
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		CustomerDataBase.readcustomerslist();
		
		Customer customer = new Customer("Kebede", LocalDate.of(1998, 9, 23));
//		customer.addAcct(new SavingAcct(LocalDate.of(2018, 4, 21), 1009, 10000, 2));
//		customer.addAcct(new CheckingAcct(LocalDate.of(2018, 4, 23), 1109, 2000, 1));
//		customer.readAllAcct().get(0).deposit(100);
//		customer.readAllAcct().get(1).deposit(100);
//		customer.readAllAcct().get(0).withdraw(50);
//		//customer.readAllAcct().get(1).deposit(100);
	//	existing.add(customer);
		CustomerDataBase.addCustomer(customer);
		CustomerDataBase.SaveToFile();;
		
//		for (Customer c: CustomerDataBase.readcustomerslist()) {
//			System.out.println(c);
//					for (Account a: c.readAllAcct()) {
//						System.out.println(a);
//					}
//		}
		
		//CustomerDataBase.saveFile();
	}
}
