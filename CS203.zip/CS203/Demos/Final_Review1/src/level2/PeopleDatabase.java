package level2;

import java.util.ArrayList;
import java.util.List;

public class PeopleDatabase {
	private static List<Person> people = new ArrayList<>();
	
	public static void addPerson(Person person) {
		people.add(person);
	}
	
	public static List<Person> getPeople(){
		return people;
	}
}
