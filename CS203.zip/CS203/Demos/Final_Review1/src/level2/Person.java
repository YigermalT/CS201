package level2;

import java.time.LocalDate;

public class Person {
	private String name;
	private LocalDate dob;
	private Address address;

	public Person() {
		this("Unknown", null, null);
	}

	public Person(String name, LocalDate dob, Address address) {
		super();
		this.name = name;
		this.dob = dob;
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", dob=" + dob + ", address=" + address + "]";
	}
}
