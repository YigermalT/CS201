package level2;

import java.awt.List;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		boolean next = true;
		Scanner scanner = new Scanner(System.in);
		scanner.useDelimiter(System.lineSeparator());
		while (next) {
			System.out.println("Enter person detials as promted: ");
			System.out.print("\tEnter name: ");
			String name = scanner.next();
			System.out.print("\tEnter Date of birth: ");
			String dob = scanner.next();
			String[] splittedDOB = dob.split("/");
			System.out.println("Enter address detials as promted: ");
			System.out.print("\tEnter street: ");
			String street = scanner.next();
			System.out.print("\tEnter city: ");
			String city = scanner.next();
			System.out.print("\tEnter state: ");
			String state = scanner.next();
			System.out.print("\tEnter zip: ");
			String zip = scanner.next();

			Address address = new Address(street, city, state, Integer.parseInt(zip));
			Person person = new Person(name, LocalDate.of(Integer.parseInt(splittedDOB[0]),
					Integer.parseInt(splittedDOB[1]), Integer.parseInt(splittedDOB[2])), address);
			
			PeopleDatabase.addPerson(person);

			System.out.println("Add another person?");
			String response = scanner.next();
			if ("no".equalsIgnoreCase(response)) {
				next = false;
			}
		}

//		Address a1 = new Address("2000 N Court", "Fairfield", "IA", 52556);
//		Address a2 = new Address("1000 N 4th St", "Fairfield", "IA", 52557);
//
//		Person p1 = new Person("John Kelly", LocalDate.of(1990, 11, 23), a1);
//		Person p2 = new Person("Jimmy Carter", LocalDate.of(1888, 7, 16), a2);
//
//		PeopleDatabase.addPerson(p1);
//		PeopleDatabase.addPerson(p2);

		for (Person p : PeopleDatabase.getPeople()) {
			System.out.println(p);
		}

	}
}
