package com.example.review;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Application {
	public static void main(String[] args) throws IOException {
		
//		Employee[] empArr = {
//				new FullTimeEmployee(123, "John", 5000, 200),  
//				new FullTimeEmployee(234, "Jack", 6000, 300),  
//				new PartTimeEmployee(567, "Martha", 2000, 100000),
//				new PartTimeEmployee(577, "Marry", 2500, 14000) 
//		};
//		
//		List<Employee> employees = Arrays.asList(empArr);
		
		
		List<Employee> employees = new ArrayList<>();
		employees.add(new FullTimeEmployee(123, "John", 5000, 200));
		employees.add(new FullTimeEmployee(234, "Jack", 6000, 300));
		employees.add(new PartTimeEmployee(567, "Martha", 2000, 100000));
		employees.add(new PartTimeEmployee(577, "Marry", 2500, 14000));
		EmployeeDataBase.saveFile();
		
		for(Employee e: employees) {
			System.out.println(e.getSalary());
		}
	}
}

