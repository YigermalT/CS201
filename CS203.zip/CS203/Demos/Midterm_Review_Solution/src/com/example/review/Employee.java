package com.example.review;

public abstract class Employee {
	protected int employeeId;
	protected String name;
	protected double baseSalary;

	
	public Employee(int employeeId, String name, double salary) {
		this.employeeId = employeeId;
		this.name = name;
		this.baseSalary = salary;
	}

	public double getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(double salary) {
		this.baseSalary = salary;
	}
	
	public abstract double getSalary();
	
}
