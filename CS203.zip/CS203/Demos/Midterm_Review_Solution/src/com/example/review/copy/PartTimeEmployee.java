package com.example.review.copy;

public class PartTimeEmployee extends Employee{
	private double monthlyTotalSale;

	public PartTimeEmployee(int employeeId, String name, double salary, double monthlyTotalSale) {
		super(employeeId, name, salary);
		this.monthlyTotalSale = monthlyTotalSale;
	}

	
	@Override
	public double getSalary() {
		double commision;
		
		if(monthlyTotalSale>1000) {
			commision = 100;
		}else {
			commision = 10;
		}
		
		return getBaseSalary() + commision;
	}
	
}
