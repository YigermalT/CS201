package com.example.review;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;


public class EmployeeDataBase {

	private static List<Employee> employeeList = new ArrayList<>();

	public static void addEmployee(Employee e) {
		employeeList.add(e);
	}

	public static List<Employee> readEmplooyeeList() throws ClassNotFoundException, IOException {
		readList();
		return employeeList;
	}
public static void saveFile() throws IOException {
	File file = new File("C:\\Users\\abush\\Desktop\\employee.dat");
	FileOutputStream fOut = new FileOutputStream(file);
	ObjectOutputStream Oout = new ObjectOutputStream(fOut);
	Oout.writeObject(employeeList);
	Oout.close();
	
	
}
		
	public static void readList() throws IOException, ClassNotFoundException {
		File file = new File("C:\\Users\\abush\\Desktop\\employee.dat"); 
		if(file.exists()) {
			FileInputStream inputStream = new FileInputStream(file);
			ObjectInputStream objectinput = new ObjectInputStream(inputStream);
			employeeList = (List<Employee>) objectinput.readObject(); 
			objectinput.close();
		}
	}
}
