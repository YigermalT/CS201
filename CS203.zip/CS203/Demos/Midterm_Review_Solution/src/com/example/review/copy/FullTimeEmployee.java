package com.example.review.copy;

public class FullTimeEmployee extends Employee {
	private double bonous;

	public FullTimeEmployee(int employeeId, String name, double salary, double bonous) {
		super(employeeId, name, salary);
		this.bonous = bonous;
	}

	
	@Override
	public  double getSalary() {
		return baseSalary+bonous;
	}
}
