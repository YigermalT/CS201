/**
 * 
 */
package com.example.calculator2;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * @author Rakesh Shrestha
 *
 */
public class Calculator extends JFrame {
	
	JLabel resultLable;
	JTextField operand1, operand2;
	public Calculator() {
		setTitle("Poor man's calculator");
		setSize(200, 300);
		
		operand1 = new JTextField(10);
		operand2 = new JTextField(10);
		JButton addButton = new JButton("ADD");
		ButtonListener listener = new ButtonListener();
		addButton.addActionListener(listener);
		JButton subtractButton = new JButton("SUBTRACT");
		subtractButton.addActionListener(listener);
		resultLable = new JLabel();
		
		Container container = getContentPane();
		container.setLayout(new FlowLayout());
		container.add(operand1);
		container.add(operand2);
		container.add(addButton);
		container.add(subtractButton);
		container.add(resultLable);
	}
	
	
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		calculator.setVisible(true);
	}
	
	
	public class ButtonListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			JButton source = (JButton) e.getSource();
//			JFrame container =  (JFrame)source.getParent().getParent();
//			
//			System.out.println(container.getTitle());

			if ("ADD".equals(source.getText())) {
				double op1Vlaue = Double.parseDouble(operand1.getText());
				double op2Vlaue = Double.parseDouble(operand2.getText());
				double result =  op1Vlaue + op2Vlaue;
				resultLable.setText(result+"");
			}else if ("SUBTRACT".contentEquals(source.getText())) {
				double op1Vlaue = Double.parseDouble(operand1.getText());
				double op2Vlaue = Double.parseDouble(operand2.getText());
				double result =  op1Vlaue - op2Vlaue;
				resultLable.setText(result+"");
			}
		}

	}
}
