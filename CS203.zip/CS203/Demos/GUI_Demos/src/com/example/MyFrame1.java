package com.example;

import java.awt.Color;

import javax.swing.JFrame;

public class MyFrame1 extends JFrame {
	private static final int FRAME_WIDTH = 800;
	private static final int FRAME_HEIGHT = 500;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAMKE_Y_ORIGIN = 250;
	
	public MyFrame1() {
		setTitle("My First own JFrmae");
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		setLocation(FRAME_X_ORIGIN, FRAMKE_Y_ORIGIN);
//		this.getContentPane().setBackground(Color.BLUE);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		JFrame myFrame = new MyFrame1();
		myFrame.setVisible(true);
	}
}
