package com.example;

import javax.swing.JOptionPane;

public class DialogBoxTest {
	public static void main(String[] args) {
//		JOptionPane.showMessageDialog(null, "I Love Java");
		String inputStr = JOptionPane.showInputDialog(null, "What is your name?");
		//System.out.println("Welcome to Java world "+inputStr);
		JOptionPane.showMessageDialog(null, "Welcome to Java world "+inputStr);
	}
}
