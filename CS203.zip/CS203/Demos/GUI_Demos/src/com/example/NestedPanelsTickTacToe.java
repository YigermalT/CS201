package com.example;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.example.tick_tac_toe.TicTacToePanel;

public class NestedPanelsTickTacToe extends JFrame {
	private static final int FRAME_WIDTH = 500;
	private static final int FRAME_HEIGHT = 350;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAME_Y_ORIGIN = 250;

	public static void main(String[] args) {
		NestedPanelsTickTacToe frame = new NestedPanelsTickTacToe();
		frame.setVisible(true);
	}

	public NestedPanelsTickTacToe() {
		Container contentPane;
		TicTacToePanel gamePanel;
		JPanel controlPanel;
		JPanel scorePanel;

		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setTitle("Program Ch14NestedPanels1");
		this.setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);
		
		contentPane = this.getContentPane();
		contentPane.setLayout(new BorderLayout(10, 0));
		
		gamePanel = new TicTacToePanel();
		gamePanel.setBorder(BorderFactory.createLoweredBevelBorder());
		
		controlPanel = new JPanel();
		controlPanel.setLayout(new BorderLayout());
		
		
		scorePanel = new JPanel();
		scorePanel.setBorder(BorderFactory.createTitledBorder("Scores: "));
		scorePanel.setLayout(new GridLayout(2, 2));
		scorePanel.add(new JLabel("Player 1"));
		scorePanel.add(new JLabel("     0"));
		scorePanel.add(new JLabel("Player 2"));
		scorePanel.add(new JLabel("     0"));
		
		controlPanel.add(scorePanel, BorderLayout.NORTH);
		controlPanel.add(new JButton("New Game"), BorderLayout.SOUTH);
		
		contentPane.add(gamePanel, BorderLayout.CENTER);
		contentPane.add(controlPanel, BorderLayout.EAST);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}
