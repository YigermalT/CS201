package com.example.tick_tac_toe;

import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

public class TicTacToePanel extends JPanel implements MouseListener {
	
	private boolean circle;
	
	public TicTacToePanel() {
		this(3);
	}
	
	public TicTacToePanel(int size) {
		TicTacToeCell cell;
		
		this.setLayout(new GridLayout(size, size));
		
		for (int row=0; row<size; row++) {
			for(int col=0; col<size; col++) {
				cell = new TicTacToeCell();
				cell.addMouseListener(this);
				this.add(cell);
			}
		}
		
		circle = true;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		TicTacToeCell cell = (TicTacToeCell) e.getSource();
		
		if(circle) {
			cell.setContent(TicTacToeCell.Image.CIRCLE);
		} else {
			cell.setContent(TicTacToeCell.Image.CROSS);
		}
		circle = !circle;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
