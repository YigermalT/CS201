package com.example;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class MyFrameWithTextArea extends JFrame {
	private static final int FRAME_WIDTH = 800;
	private static final int FRAME_HEIGHT = 500;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAMKE_Y_ORIGIN = 250;
	
	JTextArea textArea;
	
	public MyFrameWithTextArea() {
		this.setTitle("JFrame with inputs");
		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setLocation(FRAME_X_ORIGIN, FRAMKE_Y_ORIGIN);
		
		Container contentPane = this.getContentPane();
		contentPane.setLayout(new FlowLayout());
		
		textArea = new JTextArea(5, 50);
		contentPane.add(textArea);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		contentPane.add(scrollPane);
		
		JTextField input = new JTextField(50);
		InputListener listener = new InputListener();
		input.addActionListener(listener);
		
		contentPane.add(input);
	
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class InputListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			textArea.append(((JTextField)e.getSource()).getText()+"\n");
		}
	}
	
	public static void main(String[] args) {
		MyFrameWithTextArea frame = new MyFrameWithTextArea();
		frame.setVisible(true);
	}
}
