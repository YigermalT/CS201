package com.example;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JRootPane;

public class MyFrameWithLayoutAndButtons extends JFrame {
	private static final int FRAME_WIDTH = 800;
	private static final int FRAME_HEIGHT = 500;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAMKE_Y_ORIGIN = 250;
	
	public MyFrameWithLayoutAndButtons() {
		this.setTitle("My First own JFrmae");
		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setLocation(FRAME_X_ORIGIN, FRAMKE_Y_ORIGIN);
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());
		
		JButton okButton = new JButton("OK");
		
		
		JButton cancelButton = new JButton("CANCEL");
		ButtonListener listener = new ButtonListener();
		okButton.addActionListener(listener);
		cancelButton.addActionListener(listener);
		
		contentPane.add(okButton);
		contentPane.add(cancelButton);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		JFrame myFrameWithLayout = new MyFrameWithLayoutAndButtons();
		myFrameWithLayout.setVisible(true);
	}
}
