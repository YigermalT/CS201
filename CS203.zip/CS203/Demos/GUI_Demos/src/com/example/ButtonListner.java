package com.example;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

class ButtonListener implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent event) {	
		JButton clickedButton = (JButton) event.getSource();

		
		JFrame frame = (JFrame) clickedButton.getRootPane().getParent();
		frame.setTitle("You clicked "+clickedButton.getText());
	}
	
}