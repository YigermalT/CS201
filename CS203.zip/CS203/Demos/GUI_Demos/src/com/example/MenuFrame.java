package com.example;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class MenuFrame extends JFrame implements ActionListener {

	private static final int FRAME_WIDTH = 800;
	private static final int FRAME_HEIGHT = 500;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAME_Y_ORIGIN = 250;

	private JLabel response;
	private JMenu fileMenu;
	private JMenu editMenu;

	public static void main(String[] args) {
		MenuFrame frame = new MenuFrame();
		frame.setVisible(true);
	}

	public MenuFrame() {
		Container contentPane;

		this.setTitle("MenuFrameDemo");
		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);

		contentPane = this.getContentPane();
		contentPane.setLayout(new FlowLayout());
		
		this.createFileMenu();
		this.createEditMenu();
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.add(fileMenu);
		menuBar.add(editMenu);
		this.setJMenuBar(menuBar);
		
		response = new JLabel("Hello, this is your menu tester.");
		response.setSize(250,50);
		contentPane.add(response);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	private void createFileMenu() {
		JMenuItem item;

		fileMenu = new JMenu("File");

		item = new JMenuItem("New");
		item.addActionListener(this);
		fileMenu.add(item);

		item = new JMenuItem("Open...");
		item.addActionListener(this);
		fileMenu.add(item);

		item = new JMenuItem("Save");
		item.addActionListener(this);
		fileMenu.add(item);

		item = new JMenuItem("Save As...");
		item.addActionListener(this);
		fileMenu.add(item);

		fileMenu.addSeparator();

		item = new JMenuItem("Quit");
		item.addActionListener(this);
		fileMenu.add(item);
	}

	private void createEditMenu() {
		JMenuItem item;

		editMenu = new JMenu("Edit");

		item = new JMenuItem("Cut");
		item.addActionListener(this);
		editMenu.add(item);

		item = new JMenuItem("Copy");
		item.addActionListener(this);
		editMenu.add(item);

		item = new JMenuItem("Paste");
		item.addActionListener(this);
		editMenu.add(item);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String menuName;
		
		menuName = e.getActionCommand();
		
		if("Quit".equals(menuName)) {
			System.exit(0);
		} else {
			response.setText("Menu Item '" + menuName +"' is selected.");
		}

	}

}
