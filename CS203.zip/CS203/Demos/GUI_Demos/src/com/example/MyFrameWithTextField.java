package com.example;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class MyFrameWithTextField extends JFrame {
	private static final int FRAME_WIDTH = 800;
	private static final int FRAME_HEIGHT = 500;
	private static final int FRAME_X_ORIGIN = 150;
	private static final int FRAMKE_Y_ORIGIN = 250;
	
	public MyFrameWithTextField() {
		this.setTitle("JFrame with inputs");
		this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		this.setLocation(FRAME_X_ORIGIN, FRAMKE_Y_ORIGIN);
		
		Container contentPane = this.getContentPane();
		contentPane.setLayout(new FlowLayout());
		
		JLabel textLabel = new JLabel("Please enter your name");
		contentPane.add(textLabel);
		
		JTextField input = new JTextField(10);
		InputListener listener = new InputListener();
		input.addActionListener(listener);
		
		contentPane.add(input);
	
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class InputListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println(((JTextField)e.getSource()).getText());
		}
	}
	
	public static void main(String[] args) {
		MyFrameWithTextField frame = new MyFrameWithTextField();
		frame.setVisible(true);
	}
}
