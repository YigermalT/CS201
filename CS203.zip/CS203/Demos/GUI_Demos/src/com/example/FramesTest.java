package com.example;

import java.awt.Container;

import javax.swing.JFrame;

public class FramesTest {
	public static void main(String[] args) {
		JFrame defaultFrame;
		defaultFrame = new JFrame();
		defaultFrame.setVisible(true);
	}
}
